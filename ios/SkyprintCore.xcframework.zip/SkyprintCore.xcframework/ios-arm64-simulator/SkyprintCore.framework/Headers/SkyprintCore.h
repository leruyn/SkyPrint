#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SkyprintCoreAlign, SkyprintCoreAsciiFolding, SkyprintCoreBarcodeType, SkyprintCoreBleCharacteristicInfo, SkyprintCoreBleConfig, SkyprintCoreBleDefaults, SkyprintCoreBuzzerCommand, SkyprintCoreCapabilityFilter, SkyprintCoreColumn, SkyprintCoreDither, SkyprintCoreElementBarcode, SkyprintCoreElementBeep, SkyprintCoreElementCut, SkyprintCoreElementDivider, SkyprintCoreElementDrawer, SkyprintCoreElementFeed, SkyprintCoreElementImage, SkyprintCoreElementQrCode, SkyprintCoreElementRow, SkyprintCoreElementText, SkyprintCoreEscPosEncoder, SkyprintCoreKotlinArray<T>, SkyprintCoreKotlinByteArray, SkyprintCoreKotlinByteIterator, SkyprintCoreKotlinEnum<E>, SkyprintCoreKotlinEnumCompanion, SkyprintCoreKotlinException, SkyprintCoreKotlinIllegalStateException, SkyprintCoreKotlinPair<__covariant A, __covariant B>, SkyprintCoreKotlinRuntimeException, SkyprintCoreKotlinThrowable, SkyprintCoreLanConfig, SkyprintCoreLanProbe, SkyprintCoreMonoBitmap, SkyprintCorePaperWidth, SkyprintCorePrintResultFailure, SkyprintCorePrintResultSuccess, SkyprintCorePrinterCapabilities, SkyprintCorePrinterCapabilitiesCompanion, SkyprintCorePrinterErrorCode, SkyprintCorePrinterInfo, SkyprintCoreQrErrorCorrection, SkyprintCoreRasterBlock, SkyprintCoreRasterLine, SkyprintCoreRasterPacker, SkyprintCoreRasterSpan, SkyprintCoreReceiptDocument, SkyprintCoreRetryPolicy, SkyprintCoreSubnetScanner, SkyprintCoreTextMode, SkyprintCoreTextStyle, SkyprintCoreTransportKind;

@protocol SkyprintCoreElement, SkyprintCoreKotlinComparable, SkyprintCoreKotlinFunction, SkyprintCoreKotlinIterator, SkyprintCoreKotlinSuspendFunction3, SkyprintCoreKotlinx_coroutines_coreFlow, SkyprintCoreKotlinx_coroutines_coreFlowCollector, SkyprintCoreLocalSubnetProvider, SkyprintCorePrintResult, SkyprintCorePrinterConnection, SkyprintCorePrinterDiscovery, SkyprintCorePrinterTransport, SkyprintCoreTextRasterizer;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface SkyprintCoreBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface SkyprintCoreBase (SkyprintCoreBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface SkyprintCoreMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SkyprintCoreMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorSkyprintCoreKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface SkyprintCoreNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface SkyprintCoreByte : SkyprintCoreNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface SkyprintCoreUByte : SkyprintCoreNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface SkyprintCoreShort : SkyprintCoreNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface SkyprintCoreUShort : SkyprintCoreNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface SkyprintCoreInt : SkyprintCoreNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface SkyprintCoreUInt : SkyprintCoreNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface SkyprintCoreLong : SkyprintCoreNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface SkyprintCoreULong : SkyprintCoreNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface SkyprintCoreFloat : SkyprintCoreNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface SkyprintCoreDouble : SkyprintCoreNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface SkyprintCoreBoolean : SkyprintCoreNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end


/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleCharacteristicInfo")))
@interface SkyprintCoreBleCharacteristicInfo : SkyprintCoreBase
- (instancetype)initWithServiceUuid:(NSString *)serviceUuid characteristicUuid:(NSString *)characteristicUuid writableWithResponse:(BOOL)writableWithResponse writableWithoutResponse:(BOOL)writableWithoutResponse __attribute__((swift_name("init(serviceUuid:characteristicUuid:writableWithResponse:writableWithoutResponse:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreBleCharacteristicInfo *)doCopyServiceUuid:(NSString *)serviceUuid characteristicUuid:(NSString *)characteristicUuid writableWithResponse:(BOOL)writableWithResponse writableWithoutResponse:(BOOL)writableWithoutResponse __attribute__((swift_name("doCopy(serviceUuid:characteristicUuid:writableWithResponse:writableWithoutResponse:)")));

/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *characteristicUuid __attribute__((swift_name("characteristicUuid")));
@property (readonly) NSString *serviceUuid __attribute__((swift_name("serviceUuid")));
@property (readonly) BOOL writableWithResponse __attribute__((swift_name("writableWithResponse")));
@property (readonly) BOOL writableWithoutResponse __attribute__((swift_name("writableWithoutResponse")));
@end


/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleConfig")))
@interface SkyprintCoreBleConfig : SkyprintCoreBase
- (instancetype)initWithServiceUuid:(NSString * _Nullable)serviceUuid characteristicUuid:(NSString * _Nullable)characteristicUuid knownPairs:(NSArray<SkyprintCoreKotlinPair<NSString *, NSString *> *> *)knownPairs connectTimeoutMs:(int64_t)connectTimeoutMs requestMtu:(int32_t)requestMtu withoutResponsePacingMs:(int64_t)withoutResponsePacingMs __attribute__((swift_name("init(serviceUuid:characteristicUuid:knownPairs:connectTimeoutMs:requestMtu:withoutResponsePacingMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreBleConfig *)doCopyServiceUuid:(NSString * _Nullable)serviceUuid characteristicUuid:(NSString * _Nullable)characteristicUuid knownPairs:(NSArray<SkyprintCoreKotlinPair<NSString *, NSString *> *> *)knownPairs connectTimeoutMs:(int64_t)connectTimeoutMs requestMtu:(int32_t)requestMtu withoutResponsePacingMs:(int64_t)withoutResponsePacingMs __attribute__((swift_name("doCopy(serviceUuid:characteristicUuid:knownPairs:connectTimeoutMs:requestMtu:withoutResponsePacingMs:)")));

/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable characteristicUuid __attribute__((swift_name("characteristicUuid")));
@property (readonly) int64_t connectTimeoutMs __attribute__((swift_name("connectTimeoutMs")));
@property (readonly) NSArray<SkyprintCoreKotlinPair<NSString *, NSString *> *> *knownPairs __attribute__((swift_name("knownPairs")));

/** iOS không có API tương đương `requestMtu` -- dùng `maximumWriteValueLengthForType` (Kable tự trừu tượng hoá 2 nền tảng). */
@property (readonly) int32_t requestMtu __attribute__((swift_name("requestMtu")));
@property (readonly) NSString * _Nullable serviceUuid __attribute__((swift_name("serviceUuid")));

/** `WriteType.WithoutResponse` không có ack -- nghỉ giữa các gói tránh tràn buffer máy in giá rẻ. */
@property (readonly) int64_t withoutResponsePacingMs __attribute__((swift_name("withoutResponsePacingMs")));
@end


/**
 * UUID service/characteristic ghi được của các dòng máy in nhiệt BLE giá rẻ
 * phổ biến (thường thấy trên máy in mini/cầm tay Trung Quốc) -- KHÔNG phải
 * danh sách đầy đủ, chỉ là điểm khởi đầu hợp lý; máy in cụ thể của khách
 * nên cấu hình [BleConfig.serviceUuid]/[BleConfig.characteristicUuid]
 * tường minh khi biết chắc.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleDefaults")))
@interface SkyprintCoreBleDefaults : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * UUID service/characteristic ghi được của các dòng máy in nhiệt BLE giá rẻ
 * phổ biến (thường thấy trên máy in mini/cầm tay Trung Quốc) -- KHÔNG phải
 * danh sách đầy đủ, chỉ là điểm khởi đầu hợp lý; máy in cụ thể của khách
 * nên cấu hình [BleConfig.serviceUuid]/[BleConfig.characteristicUuid]
 * tường minh khi biết chắc.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)bleDefaults __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreBleDefaults *shared __attribute__((swift_name("shared")));
@property (readonly) NSArray<SkyprintCoreKotlinPair<NSString *, NSString *> *> *KNOWN_PAIRS __attribute__((swift_name("KNOWN_PAIRS")));
@end


/**
 * Một cách nói chuyện với phần cứng (USB/LAN/BT_CLASSIC/BLE, REQ-004..007).
 * [open] chỉ nên ném [com.dcorp.skyprint.core.error.PrinterException] --
 * lỗi khác bị [PrintQueue] coi là [com.dcorp.skyprint.core.error.PrinterErrorCode.UNKNOWN].
 */
__attribute__((swift_name("PrinterTransport")))
@protocol SkyprintCorePrinterTransport
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openPrinter:(SkyprintCorePrinterInfo *)printer completionHandler:(void (^)(id<SkyprintCorePrinterConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(printer:completionHandler:)")));
@property (readonly) SkyprintCoreTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Transport BLE (REQ-007, DESIGN-007) qua Kable -- `commonMain`, chạy được
 * Android và iOS không cần code riêng nền tảng (giống REQ-005's LAN, khác
 * REQ-004's USB).
 *
 * KHÔNG có test với thiết bị BLE thật (khác REQ-004 -- lúc đó có sẵn ACE3 +
 * ICOD_Thermal_Printer để verify; máy in BLE hiện chưa có sẵn để test).
 * Kable cũng không cung cấp fake/mock cho BLE stack. Phần logic ĐÃ test
 * được (không phụ thuộc thiết bị) đã tách riêng vào [CharacteristicResolver]
 * -- phần còn lại (connect/discover services/write thật) cần xác minh trên
 * thiết bị thật trước khi tin tưởng hoàn toàn, giống cách REQ-002's
 * AndroidTextRasterizer vẫn còn treo việc verify.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BlePrinterTransport")))
@interface SkyprintCoreBlePrinterTransport : SkyprintCoreBase <SkyprintCorePrinterTransport>
- (instancetype)initWithConfig:(SkyprintCoreBleConfig *)config __attribute__((swift_name("init(config:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openPrinter:(SkyprintCorePrinterInfo *)printer completionHandler:(void (^)(id<SkyprintCorePrinterConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(printer:completionHandler:)")));
@property (readonly) SkyprintCoreTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Tìm máy in theo MỘT transport (REQ-003, DESIGN-003). USB/Bluetooth
 * Classic liệt kê tức thời (không cần quét chủ động -- thiết bị đã cắm/
 * ghép nối sẵn); LAN/BLE quét chủ động trong [timeoutMs].
 */
__attribute__((swift_name("PrinterDiscovery")))
@protocol SkyprintCorePrinterDiscovery
@required
- (id<SkyprintCoreKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@property (readonly) SkyprintCoreTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Quét BLE quảng bá (advertisement) trong [timeoutMs] (REQ-003, DESIGN-003)
 * -- qua Kable, giống [com.dcorp.skyprint.core.ble.BlePrinterTransport].
 * CHƯA test với thiết bị thật (không có máy in BLE sẵn, Kable không có
 * fake cho scan -- cùng giới hạn đã ghi ở REQ-007's BlePrinterTransport).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleDiscovery")))
@interface SkyprintCoreBleDiscovery : SkyprintCoreBase <SkyprintCorePrinterDiscovery>

/**
 * Quét BLE quảng bá (advertisement) trong [timeoutMs] (REQ-003, DESIGN-003)
 * -- qua Kable, giống [com.dcorp.skyprint.core.ble.BlePrinterTransport].
 * CHƯA test với thiết bị thật (không có máy in BLE sẵn, Kable không có
 * fake cho scan -- cùng giới hạn đã ghi ở REQ-007's BlePrinterTransport).
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Quét BLE quảng bá (advertisement) trong [timeoutMs] (REQ-003, DESIGN-003)
 * -- qua Kable, giống [com.dcorp.skyprint.core.ble.BlePrinterTransport].
 * CHƯA test với thiết bị thật (không có máy in BLE sẵn, Kable không có
 * fake cho scan -- cùng giới hạn đã ghi ở REQ-007's BlePrinterTransport).
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<SkyprintCoreKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@property (readonly) SkyprintCoreTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Gộp kết quả [discoveries] chạy SONG SONG thành một luồng, khử trùng theo
 * [PrinterInfo.id] (REQ-003, DESIGN-003) -- máy in xuất hiện qua nhiều
 * transport (hiếm nhưng có thể, vd USB + BLE cùng lúc) chỉ phát ra đúng 1
 * lần, theo đúng lần đầu tìm thấy. `channelFlow` tự đóng kênh khi mọi
 * transport con đã phát xong (không cần đóng tay) và tự huỷ các job con
 * nếu người thu thập huỷ giữa chừng.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CompositeDiscovery")))
@interface SkyprintCoreCompositeDiscovery : SkyprintCoreBase
- (instancetype)initWithDiscoveries:(NSArray<id<SkyprintCorePrinterDiscovery>> *)discoveries __attribute__((swift_name("init(discoveries:)"))) __attribute__((objc_designated_initializer));
- (id<SkyprintCoreKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@end


/**
 * Dò máy in LAN bằng cách quét /24 của mạng hiện tại (REQ-003, DESIGN-003)
 * -- không tìm thấy subnet (không có mạng) thì phát ra flow rỗng, không lỗi.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanDiscovery")))
@interface SkyprintCoreLanDiscovery : SkyprintCoreBase <SkyprintCorePrinterDiscovery>
- (instancetype)initWithSubnetProvider:(id<SkyprintCoreLocalSubnetProvider>)subnetProvider port:(int32_t)port hostProbeTimeoutMs:(int64_t)hostProbeTimeoutMs concurrency:(int32_t)concurrency probe:(id<SkyprintCoreKotlinSuspendFunction3>)probe __attribute__((swift_name("init(subnetProvider:port:hostProbeTimeoutMs:concurrency:probe:)"))) __attribute__((objc_designated_initializer));
- (id<SkyprintCoreKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@property (readonly) SkyprintCoreTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Kiểm 1 host có mở cổng TCP không (REQ-003, DESIGN-003) -- dùng cho dò
 * subnet ([SubnetScanner]) lẫn "nhập IP tay rồi kiểm kết nối" của app.
 * Không phân biệt "host không tồn tại" và "có tồn tại nhưng không lắng
 * nghe cổng đó" -- cả 2 đều trả `false`, đúng nhu cầu discovery (chỉ cần
 * biết có in được không).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanProbe")))
@interface SkyprintCoreLanProbe : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Kiểm 1 host có mở cổng TCP không (REQ-003, DESIGN-003) -- dùng cho dò
 * subnet ([SubnetScanner]) lẫn "nhập IP tay rồi kiểm kết nối" của app.
 * Không phân biệt "host không tồn tại" và "có tồn tại nhưng không lắng
 * nghe cổng đó" -- cả 2 đều trả `false`, đúng nhu cầu discovery (chỉ cần
 * biết có in được không).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)lanProbe __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreLanProbe *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)probeHost:(NSString *)host port:(int32_t)port timeoutMs:(int64_t)timeoutMs completionHandler:(void (^)(SkyprintCoreBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("probe(host:port:timeoutMs:completionHandler:)")));
@end


/**
 * Lấy danh sách host trong mạng LAN hiện tại để [LanDiscovery] quét --
 * tách khỏi cách lấy IP/subnet thật (khác nhau theo nền tảng, xem
 * `createPlatformLocalSubnetProvider` androidMain) để phần thuật toán
 * quét ([SubnetScanner]) không phụ thuộc API mạng riêng của Android/iOS.
 */
__attribute__((swift_name("LocalSubnetProvider")))
@protocol SkyprintCoreLocalSubnetProvider
@required

/** `null` nếu không xác định được subnet hiện tại (không có Wi-Fi/Ethernet). */
- (NSArray<NSString *> * _Nullable)currentSubnetHosts __attribute__((swift_name("currentSubnetHosts()")));
@end


/**
 * Quét đồng thời [hosts] bằng [probe] (mặc định [LanProbe.probe]), tối đa
 * [concurrency] kết nối song song (REQ-003, DESIGN-003: "32 kết nối song
 * song") -- tách [probe] thành tham số để test bằng hàm giả, không cần
 * mạng thật.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubnetScanner")))
@interface SkyprintCoreSubnetScanner : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Quét đồng thời [hosts] bằng [probe] (mặc định [LanProbe.probe]), tối đa
 * [concurrency] kết nối song song (REQ-003, DESIGN-003: "32 kết nối song
 * song") -- tách [probe] thành tham số để test bằng hàm giả, không cần
 * mạng thật.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)subnetScanner __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreSubnetScanner *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)scanHosts:(NSArray<NSString *> *)hosts port:(int32_t)port timeoutMs:(int64_t)timeoutMs concurrency:(int32_t)concurrency probe:(id<SkyprintCoreKotlinSuspendFunction3> _Nullable)probe completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("scan(hosts:port:timeoutMs:concurrency:probe:completionHandler:)")));
@end


/**
 * Bỏ dấu tiếng Việt về ASCII cho [com.dcorp.skyprint.core.model.TextMode.ASCII]
 * (REQ-001/REQ-002's req.md doc) -- máy in nhiệt rẻ tiền không đảm bảo hỗ
 * trợ UTF-8/codepage tiếng Việt trong ROM. Ký tự ngoài bảng và ngoài ASCII
 * in được (0x20..0x7E) bị thay bằng `?` thay vì lọt UTF-8 nhiều byte xuống
 * máy in (dễ ra chuỗi rác không đoán trước được), khớp acceptance criteria
 * của req.md.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AsciiFolding")))
@interface SkyprintCoreAsciiFolding : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Bỏ dấu tiếng Việt về ASCII cho [com.dcorp.skyprint.core.model.TextMode.ASCII]
 * (REQ-001/REQ-002's req.md doc) -- máy in nhiệt rẻ tiền không đảm bảo hỗ
 * trợ UTF-8/codepage tiếng Việt trong ROM. Ký tự ngoài bảng và ngoài ASCII
 * in được (0x20..0x7E) bị thay bằng `?` thay vì lọt UTF-8 nhiều byte xuống
 * máy in (dễ ra chuỗi rác không đoán trước được), khớp acceptance criteria
 * của req.md.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)asciiFolding __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreAsciiFolding *shared __attribute__((swift_name("shared")));
- (NSString *)foldInput:(NSString *)input __attribute__((swift_name("fold(input:)")));
@end


/**
 * Lọc [ReceiptDocument] theo [PrinterCapabilities] (REQ-010) TRƯỚC khi đưa
 * vào [EscPosEncoder] -- máy in không có dao/két/còi/QR/mã vạch thì bỏ
 * hoặc thay thế phần tử tương ứng, không để [EscPosEncoder] phát byte lạ
 * xuống máy in không hiểu được (req.md acceptance: "không in ký tự rác").
 *
 * v1 chưa có QR raster fallback (cần [com.dcorp.skyprint.core.model.MonoBitmap]
 * từ REQ-002's rasterizer, hiện chưa cài) -- máy không hỗ trợ QR thì BỎ QUA
 * phần tử đó kèm cảnh báo, thay vì raster (DESIGN-010's "risk", theo dõi ở
 * REQ-002 xong mới nối lại).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CapabilityFilter")))
@interface SkyprintCoreCapabilityFilter : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Lọc [ReceiptDocument] theo [PrinterCapabilities] (REQ-010) TRƯỚC khi đưa
 * vào [EscPosEncoder] -- máy in không có dao/két/còi/QR/mã vạch thì bỏ
 * hoặc thay thế phần tử tương ứng, không để [EscPosEncoder] phát byte lạ
 * xuống máy in không hiểu được (req.md acceptance: "không in ký tự rác").
 *
 * v1 chưa có QR raster fallback (cần [com.dcorp.skyprint.core.model.MonoBitmap]
 * từ REQ-002's rasterizer, hiện chưa cài) -- máy không hỗ trợ QR thì BỎ QUA
 * phần tử đó kèm cảnh báo, thay vì raster (DESIGN-010's "risk", theo dõi ở
 * REQ-002 xong mới nối lại).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)capabilityFilter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreCapabilityFilter *shared __attribute__((swift_name("shared")));
- (SkyprintCoreKotlinPair<SkyprintCoreReceiptDocument *, NSArray<NSString *> *> *)applyDocument:(SkyprintCoreReceiptDocument *)document capabilities:(SkyprintCorePrinterCapabilities *)capabilities __attribute__((swift_name("apply(document:capabilities:)")));
@end


/**
 * Chuyển [ReceiptDocument] thành byte ESC/POS (REQ-001/DESIGN-001, mở rộng
 * nghiệp vụ POS ở DESIGN-010, chữ raster ở DESIGN-002).
 *
 * [TextMode.RASTER] gom các [Element.Text]/[Element.Row]/[Element.Divider]
 * LIÊN TIẾP thành một [com.dcorp.skyprint.core.raster.RasterBlock], gọi
 * [rasterizer] một lần cho cả nhóm (ít lệnh `GS v 0` hơn, in nhanh hơn so
 * với raster từng dòng riêng lẻ), rồi đóng gói bằng [RasterPacker]. Phần
 * tử khác (Cut/QrCode/Barcode/Drawer/Beep/Image) luôn ngắt nhóm đang gom dở.
 * [rasterizer] `null` -> [PrinterErrorCode.UNSUPPORTED_PLATFORM] ngay từ
 * đầu, không phát byte nào (chưa có bộ vẽ chữ thật theo nền tảng ở CODE-002,
 * xem CHANGELOG).
 *
 * [Element.Image] luôn dùng [RasterPacker] bất kể [mode] -- ảnh vốn đã là
 * bitmap sẵn, không cần "vẽ chữ" nên không phụ thuộc [rasterizer].
 *
 * [buzzerCommand]: chọn biến thể lệnh còi khớp máy in thật (DESIGN-010's
 * risk -- không có chuẩn chung giữa các hãng); không thuộc [PrinterCapabilities]
 * (đó là bộ lọc bật/tắt tính năng, không phải chọn cú pháp lệnh) nên truyền
 * trực tiếp vào đây, mặc định [BuzzerCommand.ESC_B] vì phổ biến nhất.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EscPosEncoder")))
@interface SkyprintCoreEscPosEncoder : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Chuyển [ReceiptDocument] thành byte ESC/POS (REQ-001/DESIGN-001, mở rộng
 * nghiệp vụ POS ở DESIGN-010, chữ raster ở DESIGN-002).
 *
 * [TextMode.RASTER] gom các [Element.Text]/[Element.Row]/[Element.Divider]
 * LIÊN TIẾP thành một [com.dcorp.skyprint.core.raster.RasterBlock], gọi
 * [rasterizer] một lần cho cả nhóm (ít lệnh `GS v 0` hơn, in nhanh hơn so
 * với raster từng dòng riêng lẻ), rồi đóng gói bằng [RasterPacker]. Phần
 * tử khác (Cut/QrCode/Barcode/Drawer/Beep/Image) luôn ngắt nhóm đang gom dở.
 * [rasterizer] `null` -> [PrinterErrorCode.UNSUPPORTED_PLATFORM] ngay từ
 * đầu, không phát byte nào (chưa có bộ vẽ chữ thật theo nền tảng ở CODE-002,
 * xem CHANGELOG).
 *
 * [Element.Image] luôn dùng [RasterPacker] bất kể [mode] -- ảnh vốn đã là
 * bitmap sẵn, không cần "vẽ chữ" nên không phụ thuộc [rasterizer].
 *
 * [buzzerCommand]: chọn biến thể lệnh còi khớp máy in thật (DESIGN-010's
 * risk -- không có chuẩn chung giữa các hãng); không thuộc [PrinterCapabilities]
 * (đó là bộ lọc bật/tắt tính năng, không phải chọn cú pháp lệnh) nên truyền
 * trực tiếp vào đây, mặc định [BuzzerCommand.ESC_B] vì phổ biến nhất.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)escPosEncoder __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreEscPosEncoder *shared __attribute__((swift_name("shared")));
- (SkyprintCoreKotlinByteArray *)encodeDocument:(SkyprintCoreReceiptDocument *)document mode:(SkyprintCoreTextMode *)mode buzzerCommand:(SkyprintCoreBuzzerCommand *)buzzerCommand rasterizer:(id<SkyprintCoreTextRasterizer> _Nullable)rasterizer __attribute__((swift_name("encode(document:mode:buzzerCommand:rasterizer:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol SkyprintCoreKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface SkyprintCoreKotlinEnum<E> : SkyprintCoreBase <SkyprintCoreKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SkyprintCoreKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end


/**
 * Mã lỗi thống nhất giữa mọi transport và cả hai bản KMP/Dart (DESIGN-008,
 * xem bảng đầy đủ + [retryable] ở docs/architecture.md của repo skyprint).
 * Encoder/document (REQ-001) chỉ dùng [INVALID_DOCUMENT] và [INVALID_TEMPLATE]
 * -- các mã còn lại thuộc transport/queue (REQ-004..008), khai đủ ở đây để
 * component nào cũng tham chiếu cùng một enum, không rải rác định nghĩa lỗi
 * theo từng module.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterErrorCode")))
@interface SkyprintCorePrinterErrorCode : SkyprintCoreKotlinEnum<SkyprintCorePrinterErrorCode *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Mã lỗi thống nhất giữa mọi transport và cả hai bản KMP/Dart (DESIGN-008,
 * xem bảng đầy đủ + [retryable] ở docs/architecture.md của repo skyprint).
 * Encoder/document (REQ-001) chỉ dùng [INVALID_DOCUMENT] và [INVALID_TEMPLATE]
 * -- các mã còn lại thuộc transport/queue (REQ-004..008), khai đủ ở đây để
 * component nào cũng tham chiếu cùng một enum, không rải rác định nghĩa lỗi
 * theo từng module.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCorePrinterErrorCode *invalidDocument __attribute__((swift_name("invalidDocument")));
@property (class, readonly) SkyprintCorePrinterErrorCode *invalidTemplate __attribute__((swift_name("invalidTemplate")));
@property (class, readonly) SkyprintCorePrinterErrorCode *permissionRequired __attribute__((swift_name("permissionRequired")));
@property (class, readonly) SkyprintCorePrinterErrorCode *permissionDenied __attribute__((swift_name("permissionDenied")));
@property (class, readonly) SkyprintCorePrinterErrorCode *unsupportedPlatform __attribute__((swift_name("unsupportedPlatform")));
@property (class, readonly) SkyprintCorePrinterErrorCode *unsupportedDevice __attribute__((swift_name("unsupportedDevice")));
@property (class, readonly) SkyprintCorePrinterErrorCode *notFound __attribute__((swift_name("notFound")));
@property (class, readonly) SkyprintCorePrinterErrorCode *adapterOff __attribute__((swift_name("adapterOff")));
@property (class, readonly) SkyprintCorePrinterErrorCode *connectTimeout __attribute__((swift_name("connectTimeout")));
@property (class, readonly) SkyprintCorePrinterErrorCode *hostUnreachable __attribute__((swift_name("hostUnreachable")));
@property (class, readonly) SkyprintCorePrinterErrorCode *disconnected __attribute__((swift_name("disconnected")));
@property (class, readonly) SkyprintCorePrinterErrorCode *writeFailed __attribute__((swift_name("writeFailed")));
@property (class, readonly) SkyprintCorePrinterErrorCode *timeout __attribute__((swift_name("timeout")));
@property (class, readonly) SkyprintCorePrinterErrorCode *cancelled __attribute__((swift_name("cancelled")));
@property (class, readonly) SkyprintCorePrinterErrorCode *unknown __attribute__((swift_name("unknown")));
+ (SkyprintCoreKotlinArray<SkyprintCorePrinterErrorCode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCorePrinterErrorCode *> *entries __attribute__((swift_name("entries")));
@property (readonly) BOOL retryable __attribute__((swift_name("retryable")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface SkyprintCoreKotlinThrowable : SkyprintCoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (SkyprintCoreKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface SkyprintCoreKotlinException : SkyprintCoreKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/** Ném khi encoder/template không thể tạo ra byte hợp lệ -- không phải lỗi transport. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterException")))
@interface SkyprintCorePrinterException : SkyprintCoreKotlinException
- (instancetype)initWithCode:(SkyprintCorePrinterErrorCode *)code message:(NSString *)message cause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(code:message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) SkyprintCorePrinterErrorCode *code __attribute__((swift_name("code")));
@end


/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanConfig")))
@interface SkyprintCoreLanConfig : SkyprintCoreBase
- (instancetype)initWithDefaultPort:(int32_t)defaultPort connectTimeoutMs:(int64_t)connectTimeoutMs writeTimeoutMs:(int64_t)writeTimeoutMs __attribute__((swift_name("init(defaultPort:connectTimeoutMs:writeTimeoutMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreLanConfig *)doCopyDefaultPort:(int32_t)defaultPort connectTimeoutMs:(int64_t)connectTimeoutMs writeTimeoutMs:(int64_t)writeTimeoutMs __attribute__((swift_name("doCopy(defaultPort:connectTimeoutMs:writeTimeoutMs:)")));

/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t connectTimeoutMs __attribute__((swift_name("connectTimeoutMs")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) int64_t writeTimeoutMs __attribute__((swift_name("writeTimeoutMs")));
@end


/**
 * Transport LAN qua raw TCP (REQ-005, DESIGN-005) -- chạy được cả Android
 * và iOS vì dùng `ktor-network` (commonMain), không phải API riêng nền
 * tảng như REQ-004's USB.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanPrinterTransport")))
@interface SkyprintCoreLanPrinterTransport : SkyprintCoreBase <SkyprintCorePrinterTransport>
- (instancetype)initWithConfig:(SkyprintCoreLanConfig *)config __attribute__((swift_name("init(config:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openPrinter:(SkyprintCorePrinterInfo *)printer completionHandler:(void (^)(id<SkyprintCorePrinterConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(printer:completionHandler:)")));
@property (readonly) SkyprintCoreTransportKind *kind __attribute__((swift_name("kind")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Align")))
@interface SkyprintCoreAlign : SkyprintCoreKotlinEnum<SkyprintCoreAlign *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCoreAlign *left __attribute__((swift_name("left")));
@property (class, readonly) SkyprintCoreAlign *center __attribute__((swift_name("center")));
@property (class, readonly) SkyprintCoreAlign *right __attribute__((swift_name("right")));
+ (SkyprintCoreKotlinArray<SkyprintCoreAlign *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCoreAlign *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Loại mã vạch 1D hỗ trợ (REQ-010). [oldStyleSymbol] khác null -> dùng lệnh
 * ESC/POS cũ `GS k m d1..dk NUL`; null -> dùng lệnh mới `GS k m n d1..dn`
 * (chỉ CODE128 cần, vì phải mang tiền tố code-set `{A/{B/{C` trong data).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BarcodeType")))
@interface SkyprintCoreBarcodeType : SkyprintCoreKotlinEnum<SkyprintCoreBarcodeType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Loại mã vạch 1D hỗ trợ (REQ-010). [oldStyleSymbol] khác null -> dùng lệnh
 * ESC/POS cũ `GS k m d1..dk NUL`; null -> dùng lệnh mới `GS k m n d1..dn`
 * (chỉ CODE128 cần, vì phải mang tiền tố code-set `{A/{B/{C` trong data).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCoreBarcodeType *upca __attribute__((swift_name("upca")));
@property (class, readonly) SkyprintCoreBarcodeType *ean13 __attribute__((swift_name("ean13")));
@property (class, readonly) SkyprintCoreBarcodeType *ean8 __attribute__((swift_name("ean8")));
@property (class, readonly) SkyprintCoreBarcodeType *code39 __attribute__((swift_name("code39")));
@property (class, readonly) SkyprintCoreBarcodeType *code128 __attribute__((swift_name("code128")));
+ (SkyprintCoreKotlinArray<SkyprintCoreBarcodeType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCoreBarcodeType *> *entries __attribute__((swift_name("entries")));
@end


/** Lệnh còi khác nhau giữa hãng máy in (DESIGN-010's risk) -- cấu hình theo máy thay vì đoán một chuẩn chung. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BuzzerCommand")))
@interface SkyprintCoreBuzzerCommand : SkyprintCoreKotlinEnum<SkyprintCoreBuzzerCommand *>
+ (instancetype)alloc __attribute__((unavailable));

/** Lệnh còi khác nhau giữa hãng máy in (DESIGN-010's risk) -- cấu hình theo máy thay vì đoán một chuẩn chung. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCoreBuzzerCommand *escB __attribute__((swift_name("escB")));
@property (class, readonly) SkyprintCoreBuzzerCommand *epsonA __attribute__((swift_name("epsonA")));
+ (SkyprintCoreKotlinArray<SkyprintCoreBuzzerCommand *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCoreBuzzerCommand *> *entries __attribute__((swift_name("entries")));
@end


/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Column")))
@interface SkyprintCoreColumn : SkyprintCoreBase
- (instancetype)initWithText:(NSString *)text weight:(int32_t)weight align:(SkyprintCoreAlign *)align bold:(BOOL)bold __attribute__((swift_name("init(text:weight:align:bold:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreColumn *)doCopyText:(NSString *)text weight:(int32_t)weight align:(SkyprintCoreAlign *)align bold:(BOOL)bold __attribute__((swift_name("doCopy(text:weight:align:bold:)")));

/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreAlign *align __attribute__((swift_name("align")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@property (readonly) int32_t weight __attribute__((swift_name("weight")));
@end


/**
 * Một phần tử trong [ReceiptDocument]. Tập hợp tối thiểu cho REQ-001 --
 * [Element.QrCode]/[Element.Image] khai interface theo DESIGN-001 nhưng nội
 * dung mã hoá byte thật của QR/ảnh raster nằm ở REQ-002 (raster)/REQ-010
 * (mã vạch, capabilities) khi các CODE đó lên; QrCode ở đây được cài đủ vì
 * nằm trong scope REQ-001 (không thuộc "Out of scope" của req.md).
 */
__attribute__((swift_name("Element")))
@protocol SkyprintCoreElement
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementBarcode")))
@interface SkyprintCoreElementBarcode : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithData:(NSString *)data type:(SkyprintCoreBarcodeType *)type heightDots:(int32_t)heightDots hri:(BOOL)hri align:(SkyprintCoreAlign *)align __attribute__((swift_name("init(data:type:heightDots:hri:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementBarcode *)doCopyData:(NSString *)data type:(SkyprintCoreBarcodeType *)type heightDots:(int32_t)heightDots hri:(BOOL)hri align:(SkyprintCoreAlign *)align __attribute__((swift_name("doCopy(data:type:heightDots:hri:align:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreAlign *align __attribute__((swift_name("align")));
@property (readonly) NSString *data __attribute__((swift_name("data")));
@property (readonly) int32_t heightDots __attribute__((swift_name("heightDots")));
@property (readonly) BOOL hri __attribute__((swift_name("hri")));
@property (readonly) SkyprintCoreBarcodeType *type __attribute__((swift_name("type")));
@end


/** Còi báo máy in bếp có phiếu mới. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementBeep")))
@interface SkyprintCoreElementBeep : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithTimes:(int32_t)times durationMs:(int32_t)durationMs __attribute__((swift_name("init(times:durationMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementBeep *)doCopyTimes:(int32_t)times durationMs:(int32_t)durationMs __attribute__((swift_name("doCopy(times:durationMs:)")));

/** Còi báo máy in bếp có phiếu mới. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Còi báo máy in bếp có phiếu mới. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Còi báo máy in bếp có phiếu mới. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t durationMs __attribute__((swift_name("durationMs")));
@property (readonly) int32_t times __attribute__((swift_name("times")));
@end


/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementCut")))
@interface SkyprintCoreElementCut : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithPartial:(BOOL)partial __attribute__((swift_name("init(partial:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementCut *)doCopyPartial:(BOOL)partial __attribute__((swift_name("doCopy(partial:)")));

/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL partial __attribute__((swift_name("partial")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementDivider")))
@interface SkyprintCoreElementDivider : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithChar:(unichar)char_ __attribute__((swift_name("init(char:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementDivider *)doCopyChar:(unichar)char_ __attribute__((swift_name("doCopy(char:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=char) unichar char_ __attribute__((swift_name("char_")));
@end


/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementDrawer")))
@interface SkyprintCoreElementDrawer : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithPin:(int32_t)pin pulseMs:(int32_t)pulseMs __attribute__((swift_name("init(pin:pulseMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementDrawer *)doCopyPin:(int32_t)pin pulseMs:(int32_t)pulseMs __attribute__((swift_name("doCopy(pin:pulseMs:)")));

/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t pin __attribute__((swift_name("pin")));
@property (readonly) int32_t pulseMs __attribute__((swift_name("pulseMs")));
@end


/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementFeed")))
@interface SkyprintCoreElementFeed : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithLines:(int32_t)lines __attribute__((swift_name("init(lines:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementFeed *)doCopyLines:(int32_t)lines __attribute__((swift_name("doCopy(lines:)")));

/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t lines __attribute__((swift_name("lines")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementImage")))
@interface SkyprintCoreElementImage : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithBitmap:(SkyprintCoreMonoBitmap *)bitmap align:(SkyprintCoreAlign *)align __attribute__((swift_name("init(bitmap:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementImage *)doCopyBitmap:(SkyprintCoreMonoBitmap *)bitmap align:(SkyprintCoreAlign *)align __attribute__((swift_name("doCopy(bitmap:align:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreAlign *align __attribute__((swift_name("align")));
@property (readonly) SkyprintCoreMonoBitmap *bitmap __attribute__((swift_name("bitmap")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementQrCode")))
@interface SkyprintCoreElementQrCode : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithData:(NSString *)data moduleSize:(int32_t)moduleSize errorCorrection:(SkyprintCoreQrErrorCorrection *)errorCorrection align:(SkyprintCoreAlign *)align __attribute__((swift_name("init(data:moduleSize:errorCorrection:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementQrCode *)doCopyData:(NSString *)data moduleSize:(int32_t)moduleSize errorCorrection:(SkyprintCoreQrErrorCorrection *)errorCorrection align:(SkyprintCoreAlign *)align __attribute__((swift_name("doCopy(data:moduleSize:errorCorrection:align:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreAlign *align __attribute__((swift_name("align")));
@property (readonly) NSString *data __attribute__((swift_name("data")));
@property (readonly) SkyprintCoreQrErrorCorrection *errorCorrection __attribute__((swift_name("errorCorrection")));
@property (readonly) int32_t moduleSize __attribute__((swift_name("moduleSize")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementRow")))
@interface SkyprintCoreElementRow : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithColumns:(NSArray<SkyprintCoreColumn *> *)columns __attribute__((swift_name("init(columns:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementRow *)doCopyColumns:(NSArray<SkyprintCoreColumn *> *)columns __attribute__((swift_name("doCopy(columns:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SkyprintCoreColumn *> *columns __attribute__((swift_name("columns")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementText")))
@interface SkyprintCoreElementText : SkyprintCoreBase <SkyprintCoreElement>
- (instancetype)initWithText:(NSString *)text style:(SkyprintCoreTextStyle *)style __attribute__((swift_name("init(text:style:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreElementText *)doCopyText:(NSString *)text style:(SkyprintCoreTextStyle *)style __attribute__((swift_name("doCopy(text:style:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreTextStyle *style __attribute__((swift_name("style")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@end


/** Ảnh 1-bit đã raster sẵn (REQ-002 tạo ra, REQ-001 chỉ cần biết hình dạng để đóng gói `GS v 0`). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MonoBitmap")))
@interface SkyprintCoreMonoBitmap : SkyprintCoreBase
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height bits:(SkyprintCoreKotlinByteArray *)bits __attribute__((swift_name("init(width:height:bits:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreMonoBitmap *)doCopyWidth:(int32_t)width height:(int32_t)height bits:(SkyprintCoreKotlinByteArray *)bits __attribute__((swift_name("doCopy(width:height:bits:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Ảnh 1-bit đã raster sẵn (REQ-002 tạo ra, REQ-001 chỉ cần biết hình dạng để đóng gói `GS v 0`). */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreKotlinByteArray *bits __attribute__((swift_name("bits")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/**
 * Khổ giấy máy in nhiệt phổ thông (DESIGN-001). [columns] là số ký tự Font A
 * chuẩn (12x24 dot), dùng để word-wrap/layout trước khi biết thật sự dùng
 * font cỡ nào; [dots] là bề rộng in được tính theo dot, dùng cho raster
 * (REQ-002) và QR.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PaperWidth")))
@interface SkyprintCorePaperWidth : SkyprintCoreKotlinEnum<SkyprintCorePaperWidth *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Khổ giấy máy in nhiệt phổ thông (DESIGN-001). [columns] là số ký tự Font A
 * chuẩn (12x24 dot), dùng để word-wrap/layout trước khi biết thật sự dùng
 * font cỡ nào; [dots] là bề rộng in được tính theo dot, dùng cho raster
 * (REQ-002) và QR.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCorePaperWidth *mm58 __attribute__((swift_name("mm58")));
@property (class, readonly) SkyprintCorePaperWidth *mm80 __attribute__((swift_name("mm80")));
+ (SkyprintCoreKotlinArray<SkyprintCorePaperWidth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCorePaperWidth *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t columns __attribute__((swift_name("columns")));
@property (readonly) int32_t dots __attribute__((swift_name("dots")));
@end


/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterCapabilities")))
@interface SkyprintCorePrinterCapabilities : SkyprintCoreBase
- (instancetype)initWithCutter:(BOOL)cutter drawer:(BOOL)drawer buzzer:(BOOL)buzzer qr:(BOOL)qr barcode:(BOOL)barcode inverse:(BOOL)inverse buzzerCommand:(SkyprintCoreBuzzerCommand *)buzzerCommand __attribute__((swift_name("init(cutter:drawer:buzzer:qr:barcode:inverse:buzzerCommand:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SkyprintCorePrinterCapabilitiesCompanion *companion __attribute__((swift_name("companion")));
- (SkyprintCorePrinterCapabilities *)doCopyCutter:(BOOL)cutter drawer:(BOOL)drawer buzzer:(BOOL)buzzer qr:(BOOL)qr barcode:(BOOL)barcode inverse:(BOOL)inverse buzzerCommand:(SkyprintCoreBuzzerCommand *)buzzerCommand __attribute__((swift_name("doCopy(cutter:drawer:buzzer:qr:barcode:inverse:buzzerCommand:)")));

/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL barcode __attribute__((swift_name("barcode")));
@property (readonly) BOOL buzzer __attribute__((swift_name("buzzer")));
@property (readonly) SkyprintCoreBuzzerCommand *buzzerCommand __attribute__((swift_name("buzzerCommand")));
@property (readonly) BOOL cutter __attribute__((swift_name("cutter")));
@property (readonly) BOOL drawer __attribute__((swift_name("drawer")));
@property (readonly) BOOL inverse __attribute__((swift_name("inverse")));
@property (readonly) BOOL qr __attribute__((swift_name("qr")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterCapabilities.Companion")))
@interface SkyprintCorePrinterCapabilitiesCompanion : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCorePrinterCapabilitiesCompanion *shared __attribute__((swift_name("shared")));

/** Dùng khi biết chắc máy in có đủ mọi phần cứng (test, hoặc máy in cao cấp đã kiểm chứng). */
@property (readonly) SkyprintCorePrinterCapabilities *ALL __attribute__((swift_name("ALL")));
@end


/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterInfo")))
@interface SkyprintCorePrinterInfo : SkyprintCoreBase
- (instancetype)initWithId:(NSString *)id name:(NSString *)name kind:(SkyprintCoreTransportKind *)kind address:(NSString *)address extras:(NSDictionary<NSString *, NSString *> *)extras __attribute__((swift_name("init(id:name:kind:address:extras:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCorePrinterInfo *)doCopyId:(NSString *)id name:(NSString *)name kind:(SkyprintCoreTransportKind *)kind address:(NSString *)address extras:(NSDictionary<NSString *, NSString *> *)extras __attribute__((swift_name("doCopy(id:name:kind:address:extras:)")));

/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *address __attribute__((swift_name("address")));
@property (readonly) NSDictionary<NSString *, NSString *> *extras __attribute__((swift_name("extras")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) SkyprintCoreTransportKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QrErrorCorrection")))
@interface SkyprintCoreQrErrorCorrection : SkyprintCoreKotlinEnum<SkyprintCoreQrErrorCorrection *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCoreQrErrorCorrection *l __attribute__((swift_name("l")));
@property (class, readonly) SkyprintCoreQrErrorCorrection *m __attribute__((swift_name("m")));
@property (class, readonly) SkyprintCoreQrErrorCorrection *q __attribute__((swift_name("q")));
@property (class, readonly) SkyprintCoreQrErrorCorrection *h __attribute__((swift_name("h")));
+ (SkyprintCoreKotlinArray<SkyprintCoreQrErrorCorrection *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCoreQrErrorCorrection *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t code __attribute__((swift_name("code")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReceiptDocument")))
@interface SkyprintCoreReceiptDocument : SkyprintCoreBase
- (instancetype)initWithPaper:(SkyprintCorePaperWidth *)paper elements:(NSArray<id<SkyprintCoreElement>> *)elements __attribute__((swift_name("init(paper:elements:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreReceiptDocument *)doCopyPaper:(SkyprintCorePaperWidth *)paper elements:(NSArray<id<SkyprintCoreElement>> *)elements __attribute__((swift_name("doCopy(paper:elements:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<id<SkyprintCoreElement>> *elements __attribute__((swift_name("elements")));
@property (readonly) SkyprintCorePaperWidth *paper __attribute__((swift_name("paper")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TextMode")))
@interface SkyprintCoreTextMode : SkyprintCoreKotlinEnum<SkyprintCoreTextMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCoreTextMode *ascii __attribute__((swift_name("ascii")));
@property (class, readonly) SkyprintCoreTextMode *raster __attribute__((swift_name("raster")));
+ (SkyprintCoreKotlinArray<SkyprintCoreTextMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCoreTextMode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TextStyle")))
@interface SkyprintCoreTextStyle : SkyprintCoreBase
- (instancetype)initWithAlign:(SkyprintCoreAlign *)align bold:(BOOL)bold width:(int32_t)width height:(int32_t)height inverse:(BOOL)inverse underline:(BOOL)underline __attribute__((swift_name("init(align:bold:width:height:inverse:underline:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreTextStyle *)doCopyAlign:(SkyprintCoreAlign *)align bold:(BOOL)bold width:(int32_t)width height:(int32_t)height inverse:(BOOL)inverse underline:(BOOL)underline __attribute__((swift_name("doCopy(align:bold:width:height:inverse:underline:)")));

/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreAlign *align __attribute__((swift_name("align")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) BOOL inverse __attribute__((swift_name("inverse")));
@property (readonly) BOOL underline __attribute__((swift_name("underline")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/**
 * Model tối thiểu từ DESIGN-003 (discovery) -- đưa vào đây SỚM vì REQ-008's
 * [com.dcorp.skyprint.core.transport.PrinterTransport] cần kiểu này để khai
 * `open(printer: PrinterInfo)`. Logic tìm máy in thật (quét USB/BLE/LAN/bonded
 * Bluetooth) CHƯA cài -- đó vẫn là REQ-003, chưa tới lượt code.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransportKind")))
@interface SkyprintCoreTransportKind : SkyprintCoreKotlinEnum<SkyprintCoreTransportKind *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Model tối thiểu từ DESIGN-003 (discovery) -- đưa vào đây SỚM vì REQ-008's
 * [com.dcorp.skyprint.core.transport.PrinterTransport] cần kiểu này để khai
 * `open(printer: PrinterInfo)`. Logic tìm máy in thật (quét USB/BLE/LAN/bonded
 * Bluetooth) CHƯA cài -- đó vẫn là REQ-003, chưa tới lượt code.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintCoreTransportKind *usb __attribute__((swift_name("usb")));
@property (class, readonly) SkyprintCoreTransportKind *lan __attribute__((swift_name("lan")));
@property (class, readonly) SkyprintCoreTransportKind *btClassic __attribute__((swift_name("btClassic")));
@property (class, readonly) SkyprintCoreTransportKind *ble __attribute__((swift_name("ble")));
+ (SkyprintCoreKotlinArray<SkyprintCoreTransportKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintCoreTransportKind *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Chuyển ảnh xám (grayscale, 1 byte/pixel, 0=đen 255=trắng) thành [MonoBitmap]
 * 1-bit bằng ngưỡng đơn giản (REQ-002). Không dùng Floyd-Steinberg hay
 * thuật toán dither nâng cao ở v1 -- text render ra glyph có cạnh rõ, không
 * cần khử răng cưa bằng dither; chỉ ảnh logo mới cần, để sau khi có nhu cầu
 * thật (không đoán trước).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Dither")))
@interface SkyprintCoreDither : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Chuyển ảnh xám (grayscale, 1 byte/pixel, 0=đen 255=trắng) thành [MonoBitmap]
 * 1-bit bằng ngưỡng đơn giản (REQ-002). Không dùng Floyd-Steinberg hay
 * thuật toán dither nâng cao ở v1 -- text render ra glyph có cạnh rõ, không
 * cần khử răng cưa bằng dither; chỉ ảnh logo mới cần, để sau khi có nhu cầu
 * thật (không đoán trước).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)dither __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreDither *shared __attribute__((swift_name("shared")));
- (SkyprintCoreMonoBitmap *)thresholdGray:(SkyprintCoreKotlinByteArray *)gray width:(int32_t)width height:(int32_t)height level:(int32_t)level __attribute__((swift_name("threshold(gray:width:height:level:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterBlock")))
@interface SkyprintCoreRasterBlock : SkyprintCoreBase
- (instancetype)initWithLines:(NSArray<SkyprintCoreRasterLine *> *)lines __attribute__((swift_name("init(lines:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreRasterBlock *)doCopyLines:(NSArray<SkyprintCoreRasterLine *> *)lines __attribute__((swift_name("doCopy(lines:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SkyprintCoreRasterLine *> *lines __attribute__((swift_name("lines")));
@end


/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterLine")))
@interface SkyprintCoreRasterLine : SkyprintCoreBase
- (instancetype)initWithSpans:(NSArray<SkyprintCoreRasterSpan *> *)spans align:(SkyprintCoreAlign *)align __attribute__((swift_name("init(spans:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreRasterLine *)doCopySpans:(NSArray<SkyprintCoreRasterSpan *> *)spans align:(SkyprintCoreAlign *)align __attribute__((swift_name("doCopy(spans:align:)")));

/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCoreAlign *align __attribute__((swift_name("align")));
@property (readonly) NSArray<SkyprintCoreRasterSpan *> *spans __attribute__((swift_name("spans")));
@end


/**
 * Đóng gói [MonoBitmap] thành lệnh ESC/POS `GS v 0` (REQ-002, DESIGN-002).
 * Chia theo dải [bandHeight] dòng dot -- máy in nhiệt rẻ tiền có buffer nhỏ,
 * gửi nguyên ảnh cao hàng nghìn dot trong 1 lệnh dễ tràn buffer/treo máy;
 * nhiều lệnh `GS v 0` liên tiếp (mỗi lệnh 1 dải) an toàn hơn dù cùng tổng
 * dữ liệu.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterPacker")))
@interface SkyprintCoreRasterPacker : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Đóng gói [MonoBitmap] thành lệnh ESC/POS `GS v 0` (REQ-002, DESIGN-002).
 * Chia theo dải [bandHeight] dòng dot -- máy in nhiệt rẻ tiền có buffer nhỏ,
 * gửi nguyên ảnh cao hàng nghìn dot trong 1 lệnh dễ tràn buffer/treo máy;
 * nhiều lệnh `GS v 0` liên tiếp (mỗi lệnh 1 dải) an toàn hơn dù cùng tổng
 * dữ liệu.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)rasterPacker __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreRasterPacker *shared __attribute__((swift_name("shared")));
- (SkyprintCoreKotlinByteArray *)toGsV0Bitmap:(SkyprintCoreMonoBitmap *)bitmap bandHeight:(int32_t)bandHeight __attribute__((swift_name("toGsV0(bitmap:bandHeight:)")));
@end


/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterSpan")))
@interface SkyprintCoreRasterSpan : SkyprintCoreBase
- (instancetype)initWithText:(NSString *)text bold:(BOOL)bold underline:(BOOL)underline inverse:(BOOL)inverse widthScale:(int32_t)widthScale heightScale:(int32_t)heightScale __attribute__((swift_name("init(text:bold:underline:inverse:widthScale:heightScale:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreRasterSpan *)doCopyText:(NSString *)text bold:(BOOL)bold underline:(BOOL)underline inverse:(BOOL)inverse widthScale:(int32_t)widthScale heightScale:(int32_t)heightScale __attribute__((swift_name("doCopy(text:bold:underline:inverse:widthScale:heightScale:)")));

/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) int32_t heightScale __attribute__((swift_name("heightScale")));
@property (readonly) BOOL inverse __attribute__((swift_name("inverse")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@property (readonly) BOOL underline __attribute__((swift_name("underline")));
@property (readonly) int32_t widthScale __attribute__((swift_name("widthScale")));
@end


/**
 * Vẽ chữ thành ảnh 1-bit theo nền tảng (REQ-002) -- Android dùng `Canvas`/
 * `StaticLayout`, iOS dùng `CoreText`, Flutter dùng `dart:ui`. CHƯA cài ở
 * CODE-002 (v1 mới có contract + [EscPosEncoder] nối vào qua interface này,
 * đã kiểm bằng rasterizer giả trong test) -- 3 cài đặt thật cần toolchain
 * Android/iOS riêng, theo dõi tiếp ở CODE-002b/CODE-002c.
 */
__attribute__((swift_name("TextRasterizer")))
@protocol SkyprintCoreTextRasterizer
@required
- (SkyprintCoreMonoBitmap *)renderBlock:(SkyprintCoreRasterBlock *)block widthDots:(int32_t)widthDots __attribute__((swift_name("render(block:widthDots:)")));
@end


/**
 * Tuần tự hoá lệnh in theo máy in, có retry/timeout/mã lỗi thống nhất
 * (REQ-008, DESIGN-008). Facade [PrinterService] (chưa cài -- gồm cả
 * encode/template) sẽ gọi [print] với byte đã dựng sẵn từ REQ-001/002/009.
 *
 * KHÔNG bắt [CancellationException] thành [PrintResult.Failure] -- app tự
 * huỷ job (`Job.cancel()`) thì lời gọi [print] tự huỷ theo (coroutine
 * convention chuẩn), không giả vờ trả về kết quả bình thường. "Transport
 * đóng sạch" khi bị huỷ (req.md's alternate flow) vẫn đảm bảo vì [attemptOnce]
 * đóng connection trong ngữ cảnh [NonCancellable].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrintQueue")))
@interface SkyprintCorePrintQueue : SkyprintCoreBase
- (instancetype)initWithTransports:(NSArray<id<SkyprintCorePrinterTransport>> *)transports policy:(SkyprintCoreRetryPolicy *)policy __attribute__((swift_name("init(transports:policy:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)printPrinter:(SkyprintCorePrinterInfo *)printer bytes:(SkyprintCoreKotlinByteArray *)bytes completionHandler:(void (^)(id<SkyprintCorePrintResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("print(printer:bytes:completionHandler:)")));
@end


/** Kết quả một lệnh in (REQ-008) -- KMP và Dart cùng hình dạng này để app dùng chung logic xử lý kết quả. */
__attribute__((swift_name("PrintResult")))
@protocol SkyprintCorePrintResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrintResultFailure")))
@interface SkyprintCorePrintResultFailure : SkyprintCoreBase <SkyprintCorePrintResult>
- (instancetype)initWithCode:(SkyprintCorePrinterErrorCode *)code message:(NSString *)message __attribute__((swift_name("init(code:message:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCorePrintResultFailure *)doCopyCode:(SkyprintCorePrinterErrorCode *)code message:(NSString *)message __attribute__((swift_name("doCopy(code:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintCorePrinterErrorCode *code __attribute__((swift_name("code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrintResultSuccess")))
@interface SkyprintCorePrintResultSuccess : SkyprintCoreBase <SkyprintCorePrintResult>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCorePrintResultSuccess *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Kết nối đang mở tới MỘT máy in (REQ-008, DESIGN-008). Vòng đời do
 * [PrintQueue] quản -- gọi [write] đúng 1 lần rồi luôn [close], kể cả khi
 * [write] lỗi.
 */
__attribute__((swift_name("PrinterConnection")))
@protocol SkyprintCorePrinterConnection
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("close(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)writeBytes:(SkyprintCoreKotlinByteArray *)bytes completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("write(bytes:completionHandler:)")));
@end


/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RetryPolicy")))
@interface SkyprintCoreRetryPolicy : SkyprintCoreBase
- (instancetype)initWithMaxRetries:(int32_t)maxRetries backoffMs:(NSArray<SkyprintCoreLong *> *)backoffMs jobTimeoutMs:(int64_t)jobTimeoutMs __attribute__((swift_name("init(maxRetries:backoffMs:jobTimeoutMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreRetryPolicy *)doCopyMaxRetries:(int32_t)maxRetries backoffMs:(NSArray<SkyprintCoreLong *> *)backoffMs jobTimeoutMs:(int64_t)jobTimeoutMs __attribute__((swift_name("doCopy(maxRetries:backoffMs:jobTimeoutMs:)")));

/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SkyprintCoreLong *> *backoffMs __attribute__((swift_name("backoffMs")));
@property (readonly) int64_t jobTimeoutMs __attribute__((swift_name("jobTimeoutMs")));
@property (readonly) int32_t maxRetries __attribute__((swift_name("maxRetries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinPair")))
@interface SkyprintCoreKotlinPair<__covariant A, __covariant B> : SkyprintCoreBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("init(first:second:)"))) __attribute__((objc_designated_initializer));
- (SkyprintCoreKotlinPair<A, B> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("doCopy(first:second:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface SkyprintCoreKotlinRuntimeException : SkyprintCoreKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface SkyprintCoreKotlinIllegalStateException : SkyprintCoreKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface SkyprintCoreKotlinCancellationException : SkyprintCoreKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintCoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * An asynchronous data stream that sequentially emits values and completes normally or with an exception.
 *
 * _Intermediate operators_ on the flow such as [map], [filter], [take], [zip], etc are functions that are
 * applied to the _upstream_ flow or flows and return a _downstream_ flow where further operators can be applied to.
 * Intermediate operations do not execute any code in the flow and are not suspending functions themselves.
 * They only set up a chain of operations for future execution and quickly return.
 * This is known as a _cold flow_ property.
 *
 * _Terminal operators_ on the flow are either suspending functions such as [collect], [single], [reduce], [toList], etc.
 * or [launchIn] operator that starts collection of the flow in the given scope.
 * They are applied to the upstream flow and trigger execution of all operations.
 * Execution of the flow is also called _collecting the flow_  and is always performed in a suspending manner
 * without actual blocking. Terminal operators complete normally or exceptionally depending on successful or failed
 * execution of all the flow operations in the upstream. The most basic terminal operator is [collect], for example:
 *
 * ```
 * try {
 *     flow.collect { value ->
 *         println("Received $value")
 *     }
 * } catch (e: Exception) {
 *     println("The flow has thrown an exception: $e")
 * }
 * ```
 *
 * By default, flows are _sequential_ and all flow operations are executed sequentially in the same coroutine,
 * with an exception for a few operations specifically designed to introduce concurrency into flow
 * execution such as [buffer] and [flatMapMerge]. See their documentation for details.
 *
 * The `Flow` interface does not carry information whether a flow is a _cold_ stream that can be collected repeatedly and
 * triggers execution of the same code every time it is collected, or if it is a _hot_ stream that emits different
 * values from the same running source on each collection. Usually flows represent _cold_ streams, but
 * there is a [SharedFlow] subtype that represents _hot_ streams. In addition to that, any flow can be turned
 * into a _hot_ one by the [stateIn] and [shareIn] operators, or by converting the flow into a hot channel
 * via the [produceIn] operator.
 *
 * ### Flow builders
 *
 * There are the following basic ways to create a flow:
 *
 * - [flowOf(...)][flowOf] functions to create a flow from a fixed set of values.
 * - [asFlow()][asFlow] extension functions on various types to convert them into flows.
 * - [flow { ... }][flow] builder function to construct arbitrary flows from
 *   sequential calls to [emit][FlowCollector.emit] function.
 * - [channelFlow { ... }][channelFlow] builder function to construct arbitrary flows from
 *   potentially concurrent calls to the [send][kotlinx.coroutines.channels.SendChannel.send] function.
 * - [MutableStateFlow] and [MutableSharedFlow] define the corresponding constructor functions to create
 *   a _hot_ flow that can be directly updated.
 *
 * ### Flow constraints
 *
 * All implementations of the `Flow` interface must adhere to two key properties described in detail below:
 *
 * - Context preservation.
 * - Exception transparency.
 *
 * These properties ensure the ability to perform local reasoning about the code with flows and modularize the code
 * in such a way that upstream flow emitters can be developed separately from downstream flow collectors.
 * A user of a flow does not need to be aware of implementation details of the upstream flows it uses.
 *
 * ### Context preservation
 *
 * The flow has a context preservation property: it encapsulates its own execution context and never propagates or leaks
 * it downstream, thus making reasoning about the execution context of particular transformations or terminal
 * operations trivial.
 *
 * There is only one way to change the context of a flow: the [flowOn][Flow.flowOn] operator
 * that changes the upstream context ("everything above the `flowOn` operator").
 * For additional information refer to its documentation.
 *
 * This reasoning can be demonstrated in practice:
 *
 * ```
 * val flowA = flowOf(1, 2, 3)
 *     .map { it + 1 } // Will be executed in ctxA
 *     .flowOn(ctxA) // Changes the upstream context: flowOf and map
 *
 * // Now we have a context-preserving flow: it is executed somewhere but this information is encapsulated in the flow itself
 *
 * val filtered = flowA // ctxA is encapsulated in flowA
 *    .filter { it == 3 } // Pure operator without a context yet
 *
 * withContext(Dispatchers.Main) {
 *     // All non-encapsulated operators will be executed in Main: filter and single
 *     val result = filtered.single()
 *     myUi.text = result
 * }
 * ```
 *
 * From the implementation point of view, it means that all flow implementations should
 * only emit from the same coroutine context.
 * This constraint is efficiently enforced by the default [flow] builder.
 * The [flow] builder should be used if the flow implementation does not start any coroutines.
 * Its implementation prevents most of the development mistakes:
 *
 * ```
 * val myFlow = flow {
 *     // GlobalScope.launch { // is prohibited
 *     // launch(Dispatchers.IO) { // is prohibited
 *     // withContext(CoroutineName("myFlow")) { // is prohibited
 *     emit(1) // OK
 *     coroutineScope {
 *         emit(2) // OK -- still the same coroutine
 *     }
 * }
 * ```
 *
 * Use [channelFlow] if the collection and emission of a flow are to be separated into multiple coroutines.
 * It encapsulates all the context preservation work and allows you to focus on your
 * domain-specific problem, rather than invariant implementation details.
 * It is possible to use any combination of coroutine builders from within [channelFlow].
 *
 * If you are looking for performance and are sure that no concurrent emits and context jumps will happen,
 * the [flow] builder can be used alongside a [coroutineScope] or [supervisorScope] instead:
 * - Scoped primitive should be used to provide a [CoroutineScope].
 * - Changing the context of emission is prohibited, no matter whether it is `withContext(ctx)` or
 *   a builder argument (e.g. `launch(ctx)`).
 * - Collecting another flow from a separate context is allowed, but it has the same effect as
 *   applying the [flowOn] operator to that flow, which is more efficient.
 *
 * ### Exception transparency
 *
 * When `emit` or `emitAll` throws, the Flow implementations must immediately stop emitting new values and finish with an exception.
 * For diagnostics or application-specific purposes, the exception may be different from the one thrown by the emit operation,
 * suppressing the original exception as discussed below.
 * If there is a need to emit values after the downstream failed, please use the [catch][Flow.catch] operator.
 *
 * The [catch][Flow.catch] operator only catches upstream exceptions, but passes
 * all downstream exceptions. Similarly, terminal operators like [collect][Flow.collect]
 * throw any unhandled exceptions that occur in their code or in upstream flows, for example:
 *
 * ```
 * flow { emitData() }
 *     .map { computeOne(it) }
 *     .catch { ... } // catches exceptions in emitData and computeOne
 *     .map { computeTwo(it) }
 *     .collect { process(it) } // throws exceptions from process and computeTwo
 * ```
 * The same reasoning can be applied to the [onCompletion] operator that is a declarative replacement for the `finally` block.
 *
 * All exception-handling Flow operators follow the principle of exception suppression:
 *
 * If the upstream flow throws an exception during its completion when the downstream exception has been thrown,
 * the downstream exception becomes superseded and suppressed by the upstream exception, being a semantic
 * equivalent of throwing from `finally` block. However, this doesn't affect the operation of the exception-handling operators,
 * which consider the downstream exception to be the root cause and behave as if the upstream didn't throw anything.
 *
 * Failure to adhere to the exception transparency requirement can lead to strange behaviors which make
 * it hard to reason about the code because an exception in the `collect { ... }` could be somehow "caught"
 * by an upstream flow, limiting the ability of local reasoning about the code.
 *
 * Flow machinery enforces exception transparency at runtime and throws [IllegalStateException] on any attempt to emit a value,
 * if an exception has been thrown on previous attempt.
 *
 * ### Reactive streams
 *
 * Flow is [Reactive Streams](http://www.reactive-streams.org/) compliant, you can safely interop it with
 * reactive streams using `Flow.asPublisher` and `Publisher.asFlow` from `kotlinx-coroutines-reactive` module.
 *
 * ### Not stable for inheritance
 *
 * **The `Flow` interface is not stable for inheritance in 3rd party libraries**, as new methods
 * might be added to this interface in the future, but is stable for use.
 *
 * Use the `flow { ... }` builder function to create an implementation, or extend [AbstractFlow].
 * These implementations ensure that the context preservation property is not violated, and prevent most
 * of the developer mistakes related to concurrency, inconsistent flow dispatchers, and cancellation.
 */
__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol SkyprintCoreKotlinx_coroutines_coreFlow
@required

/**
 * Accepts the given [collector] and [emits][FlowCollector.emit] values into it.
 *
 * This method can be used along with SAM-conversion of [FlowCollector]:
 * ```
 * myFlow.collect { value -> println("Collected $value") }
 * ```
 *
 * ### Method inheritance
 *
 * To ensure the context preservation property, it is not recommended implementing this method directly.
 * Instead, [AbstractFlow] can be used as the base type to properly ensure flow's properties.
 *
 * All default flow implementations ensure context preservation and exception transparency properties on a best-effort basis
 * and throw [IllegalStateException] if a violation was detected.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<SkyprintCoreKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol SkyprintCoreKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction3")))
@protocol SkyprintCoreKotlinSuspendFunction3 <SkyprintCoreKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 p3:(id _Nullable)p3 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:p3:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface SkyprintCoreKotlinByteArray : SkyprintCoreBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(SkyprintCoreByte *(^)(SkyprintCoreInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SkyprintCoreKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface SkyprintCoreKotlinEnumCompanion : SkyprintCoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCoreKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SkyprintCoreKotlinArray<T> : SkyprintCoreBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SkyprintCoreInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SkyprintCoreKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end


/**
 * [FlowCollector] is used as an intermediate or a terminal collector of the flow and represents
 * an entity that accepts values emitted by the [Flow].
 *
 * This interface should usually not be implemented directly, but rather used as a receiver in a [flow] builder when implementing a custom operator,
 * or with SAM-conversion.
 * Implementations of this interface are not thread-safe.
 *
 * Example of usage:
 *
 * ```
 * val flow = getMyEvents()
 * try {
 *     flow.collect { value ->
 *         println("Received $value")
 *     }
 *     println("My events are consumed successfully")
 * } catch (e: Throwable) {
 *     println("Exception from the flow: $e")
 * }
 * ```
 */
__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol SkyprintCoreKotlinx_coroutines_coreFlowCollector
@required

/**
 * Collects the value emitted by the upstream.
 * This method is not thread-safe and should not be invoked concurrently.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol SkyprintCoreKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface SkyprintCoreKotlinByteIterator : SkyprintCoreBase <SkyprintCoreKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SkyprintCoreByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
