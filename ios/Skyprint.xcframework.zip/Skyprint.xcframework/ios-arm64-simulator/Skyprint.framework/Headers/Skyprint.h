#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SkyprintAlign, SkyprintAsciiFolding, SkyprintBarcodeType, SkyprintBleCharacteristicInfo, SkyprintBleConfig, SkyprintBleDefaults, SkyprintBuzzerCommand, SkyprintCapabilityFilter, SkyprintColumn, SkyprintConditionEvaluator, SkyprintDither, SkyprintElementBarcode, SkyprintElementBeep, SkyprintElementCut, SkyprintElementDivider, SkyprintElementDrawer, SkyprintElementFeed, SkyprintElementImage, SkyprintElementQrCode, SkyprintElementRow, SkyprintElementText, SkyprintEscPosEncoder, SkyprintFormatters, SkyprintInterpolator, SkyprintKotlinArray<T>, SkyprintKotlinByteArray, SkyprintKotlinByteIterator, SkyprintKotlinEnum<E>, SkyprintKotlinEnumCompanion, SkyprintKotlinException, SkyprintKotlinIllegalStateException, SkyprintKotlinPair<__covariant A, __covariant B>, SkyprintKotlinRuntimeException, SkyprintKotlinThrowable, SkyprintLanConfig, SkyprintLanProbe, SkyprintMoneyFormat, SkyprintMoneyFormatCompanion, SkyprintMonoBitmap, SkyprintPaperWidth, SkyprintPathResolver, SkyprintPrintResultFailure, SkyprintPrintResultSuccess, SkyprintPrinterCapabilities, SkyprintPrinterCapabilitiesCompanion, SkyprintPrinterErrorCode, SkyprintPrinterInfo, SkyprintQrErrorCorrection, SkyprintRasterBlock, SkyprintRasterLine, SkyprintRasterPacker, SkyprintRasterSpan, SkyprintReceiptDocument, SkyprintRenderOptions, SkyprintRenderResult, SkyprintRetryPolicy, SkyprintSchemaValidator, SkyprintScope, SkyprintScopeCompanion, SkyprintSubnetScanner, SkyprintTemplate, SkyprintTemplateColumn, SkyprintTemplateEngine, SkyprintTemplateErrorCode, SkyprintTemplateIssue, SkyprintTemplateNode, SkyprintTemplateParser, SkyprintTemplateSchema, SkyprintTemplateStyle, SkyprintTemplateValueArr, SkyprintTemplateValueBool, SkyprintTemplateValueCompanion, SkyprintTemplateValueNull, SkyprintTemplateValueNum, SkyprintTemplateValueObj, SkyprintTemplateValueStr, SkyprintTextMode, SkyprintTextStyle, SkyprintTransportKind;

@protocol SkyprintElement, SkyprintImageResolver, SkyprintKotlinComparable, SkyprintKotlinFunction, SkyprintKotlinIterator, SkyprintKotlinSuspendFunction3, SkyprintKotlinx_coroutines_coreFlow, SkyprintKotlinx_coroutines_coreFlowCollector, SkyprintLocalSubnetProvider, SkyprintPrintResult, SkyprintPrinterConnection, SkyprintPrinterDiscovery, SkyprintPrinterTransport, SkyprintTemplateValue, SkyprintTextRasterizer;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface SkyprintBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface SkyprintBase (SkyprintBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface SkyprintMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SkyprintMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorSkyprintKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface SkyprintNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface SkyprintByte : SkyprintNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface SkyprintUByte : SkyprintNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface SkyprintShort : SkyprintNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface SkyprintUShort : SkyprintNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface SkyprintInt : SkyprintNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface SkyprintUInt : SkyprintNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface SkyprintLong : SkyprintNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface SkyprintULong : SkyprintNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface SkyprintFloat : SkyprintNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface SkyprintDouble : SkyprintNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface SkyprintBoolean : SkyprintNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end


/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleCharacteristicInfo")))
@interface SkyprintBleCharacteristicInfo : SkyprintBase
- (instancetype)initWithServiceUuid:(NSString *)serviceUuid characteristicUuid:(NSString *)characteristicUuid writableWithResponse:(BOOL)writableWithResponse writableWithoutResponse:(BOOL)writableWithoutResponse __attribute__((swift_name("init(serviceUuid:characteristicUuid:writableWithResponse:writableWithoutResponse:)"))) __attribute__((objc_designated_initializer));
- (SkyprintBleCharacteristicInfo *)doCopyServiceUuid:(NSString *)serviceUuid characteristicUuid:(NSString *)characteristicUuid writableWithResponse:(BOOL)writableWithResponse writableWithoutResponse:(BOOL)writableWithoutResponse __attribute__((swift_name("doCopy(serviceUuid:characteristicUuid:writableWithResponse:writableWithoutResponse:)")));

/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Đại diện thuần cho một characteristic ghi được, tách khỏi kiểu thật của
 * Kable ([com.juul.kable.DiscoveredCharacteristic]) để [CharacteristicResolver]
 * test được mà không cần thiết bị BLE thật (REQ-007).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *characteristicUuid __attribute__((swift_name("characteristicUuid")));
@property (readonly) NSString *serviceUuid __attribute__((swift_name("serviceUuid")));
@property (readonly) BOOL writableWithResponse __attribute__((swift_name("writableWithResponse")));
@property (readonly) BOOL writableWithoutResponse __attribute__((swift_name("writableWithoutResponse")));
@end


/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleConfig")))
@interface SkyprintBleConfig : SkyprintBase
- (instancetype)initWithServiceUuid:(NSString * _Nullable)serviceUuid characteristicUuid:(NSString * _Nullable)characteristicUuid knownPairs:(NSArray<SkyprintKotlinPair<NSString *, NSString *> *> *)knownPairs connectTimeoutMs:(int64_t)connectTimeoutMs requestMtu:(int32_t)requestMtu withoutResponsePacingMs:(int64_t)withoutResponsePacingMs __attribute__((swift_name("init(serviceUuid:characteristicUuid:knownPairs:connectTimeoutMs:requestMtu:withoutResponsePacingMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintBleConfig *)doCopyServiceUuid:(NSString * _Nullable)serviceUuid characteristicUuid:(NSString * _Nullable)characteristicUuid knownPairs:(NSArray<SkyprintKotlinPair<NSString *, NSString *> *> *)knownPairs connectTimeoutMs:(int64_t)connectTimeoutMs requestMtu:(int32_t)requestMtu withoutResponsePacingMs:(int64_t)withoutResponsePacingMs __attribute__((swift_name("doCopy(serviceUuid:characteristicUuid:knownPairs:connectTimeoutMs:requestMtu:withoutResponsePacingMs:)")));

/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Cấu hình BLE (REQ-007, DESIGN-007). [serviceUuid]/[characteristicUuid]:
 * cấu hình tường minh theo máy in cụ thể, ưu tiên cao nhất. [knownPairs]:
 * danh sách UUID phổ biến của máy in nhiệt giá rẻ (dò theo thứ tự khai,
 * xem [BleDefaults]). Không tìm thấy cặp nào khớp -> lấy characteristic
 * ghi được ĐẦU TIÊN tìm thấy (xem [CharacteristicResolver]).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable characteristicUuid __attribute__((swift_name("characteristicUuid")));
@property (readonly) int64_t connectTimeoutMs __attribute__((swift_name("connectTimeoutMs")));
@property (readonly) NSArray<SkyprintKotlinPair<NSString *, NSString *> *> *knownPairs __attribute__((swift_name("knownPairs")));

/** iOS không có API tương đương `requestMtu` -- dùng `maximumWriteValueLengthForType` (Kable tự trừu tượng hoá 2 nền tảng). */
@property (readonly) int32_t requestMtu __attribute__((swift_name("requestMtu")));
@property (readonly) NSString * _Nullable serviceUuid __attribute__((swift_name("serviceUuid")));

/** `WriteType.WithoutResponse` không có ack -- nghỉ giữa các gói tránh tràn buffer máy in giá rẻ. */
@property (readonly) int64_t withoutResponsePacingMs __attribute__((swift_name("withoutResponsePacingMs")));
@end


/**
 * UUID service/characteristic ghi được của các dòng máy in nhiệt BLE giá rẻ
 * phổ biến (thường thấy trên máy in mini/cầm tay Trung Quốc) -- KHÔNG phải
 * danh sách đầy đủ, chỉ là điểm khởi đầu hợp lý; máy in cụ thể của khách
 * nên cấu hình [BleConfig.serviceUuid]/[BleConfig.characteristicUuid]
 * tường minh khi biết chắc.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleDefaults")))
@interface SkyprintBleDefaults : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * UUID service/characteristic ghi được của các dòng máy in nhiệt BLE giá rẻ
 * phổ biến (thường thấy trên máy in mini/cầm tay Trung Quốc) -- KHÔNG phải
 * danh sách đầy đủ, chỉ là điểm khởi đầu hợp lý; máy in cụ thể của khách
 * nên cấu hình [BleConfig.serviceUuid]/[BleConfig.characteristicUuid]
 * tường minh khi biết chắc.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)bleDefaults __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintBleDefaults *shared __attribute__((swift_name("shared")));
@property (readonly) NSArray<SkyprintKotlinPair<NSString *, NSString *> *> *KNOWN_PAIRS __attribute__((swift_name("KNOWN_PAIRS")));
@end


/**
 * Một cách nói chuyện với phần cứng (USB/LAN/BT_CLASSIC/BLE, REQ-004..007).
 * [open] chỉ nên ném [com.dcorp.skyprint.core.error.PrinterException] --
 * lỗi khác bị [PrintQueue] coi là [com.dcorp.skyprint.core.error.PrinterErrorCode.UNKNOWN].
 */
__attribute__((swift_name("PrinterTransport")))
@protocol SkyprintPrinterTransport
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openPrinter:(SkyprintPrinterInfo *)printer completionHandler:(void (^)(id<SkyprintPrinterConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(printer:completionHandler:)")));
@property (readonly) SkyprintTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Transport BLE (REQ-007, DESIGN-007) qua Kable -- `commonMain`, chạy được
 * Android và iOS không cần code riêng nền tảng (giống REQ-005's LAN, khác
 * REQ-004's USB).
 *
 * KHÔNG có test với thiết bị BLE thật (khác REQ-004 -- lúc đó có sẵn ACE3 +
 * ICOD_Thermal_Printer để verify; máy in BLE hiện chưa có sẵn để test).
 * Kable cũng không cung cấp fake/mock cho BLE stack. Phần logic ĐÃ test
 * được (không phụ thuộc thiết bị) đã tách riêng vào [CharacteristicResolver]
 * -- phần còn lại (connect/discover services/write thật) cần xác minh trên
 * thiết bị thật trước khi tin tưởng hoàn toàn, giống cách REQ-002's
 * AndroidTextRasterizer vẫn còn treo việc verify.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BlePrinterTransport")))
@interface SkyprintBlePrinterTransport : SkyprintBase <SkyprintPrinterTransport>
- (instancetype)initWithConfig:(SkyprintBleConfig *)config __attribute__((swift_name("init(config:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openPrinter:(SkyprintPrinterInfo *)printer completionHandler:(void (^)(id<SkyprintPrinterConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(printer:completionHandler:)")));
@property (readonly) SkyprintTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Tìm máy in theo MỘT transport (REQ-003, DESIGN-003). USB/Bluetooth
 * Classic liệt kê tức thời (không cần quét chủ động -- thiết bị đã cắm/
 * ghép nối sẵn); LAN/BLE quét chủ động trong [timeoutMs].
 */
__attribute__((swift_name("PrinterDiscovery")))
@protocol SkyprintPrinterDiscovery
@required
- (id<SkyprintKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@property (readonly) SkyprintTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Quét BLE quảng bá (advertisement) trong [timeoutMs] (REQ-003, DESIGN-003)
 * -- qua Kable, giống [com.dcorp.skyprint.core.ble.BlePrinterTransport].
 * CHƯA test với thiết bị thật (không có máy in BLE sẵn, Kable không có
 * fake cho scan -- cùng giới hạn đã ghi ở REQ-007's BlePrinterTransport).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BleDiscovery")))
@interface SkyprintBleDiscovery : SkyprintBase <SkyprintPrinterDiscovery>

/**
 * Quét BLE quảng bá (advertisement) trong [timeoutMs] (REQ-003, DESIGN-003)
 * -- qua Kable, giống [com.dcorp.skyprint.core.ble.BlePrinterTransport].
 * CHƯA test với thiết bị thật (không có máy in BLE sẵn, Kable không có
 * fake cho scan -- cùng giới hạn đã ghi ở REQ-007's BlePrinterTransport).
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Quét BLE quảng bá (advertisement) trong [timeoutMs] (REQ-003, DESIGN-003)
 * -- qua Kable, giống [com.dcorp.skyprint.core.ble.BlePrinterTransport].
 * CHƯA test với thiết bị thật (không có máy in BLE sẵn, Kable không có
 * fake cho scan -- cùng giới hạn đã ghi ở REQ-007's BlePrinterTransport).
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<SkyprintKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@property (readonly) SkyprintTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Gộp kết quả [discoveries] chạy SONG SONG thành một luồng, khử trùng theo
 * [PrinterInfo.id] (REQ-003, DESIGN-003) -- máy in xuất hiện qua nhiều
 * transport (hiếm nhưng có thể, vd USB + BLE cùng lúc) chỉ phát ra đúng 1
 * lần, theo đúng lần đầu tìm thấy. `channelFlow` tự đóng kênh khi mọi
 * transport con đã phát xong (không cần đóng tay) và tự huỷ các job con
 * nếu người thu thập huỷ giữa chừng.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CompositeDiscovery")))
@interface SkyprintCompositeDiscovery : SkyprintBase
- (instancetype)initWithDiscoveries:(NSArray<id<SkyprintPrinterDiscovery>> *)discoveries __attribute__((swift_name("init(discoveries:)"))) __attribute__((objc_designated_initializer));
- (id<SkyprintKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@end


/**
 * Dò máy in LAN bằng cách quét /24 của mạng hiện tại (REQ-003, DESIGN-003)
 * -- không tìm thấy subnet (không có mạng) thì phát ra flow rỗng, không lỗi.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanDiscovery")))
@interface SkyprintLanDiscovery : SkyprintBase <SkyprintPrinterDiscovery>
- (instancetype)initWithSubnetProvider:(id<SkyprintLocalSubnetProvider>)subnetProvider port:(int32_t)port hostProbeTimeoutMs:(int64_t)hostProbeTimeoutMs concurrency:(int32_t)concurrency probe:(id<SkyprintKotlinSuspendFunction3>)probe __attribute__((swift_name("init(subnetProvider:port:hostProbeTimeoutMs:concurrency:probe:)"))) __attribute__((objc_designated_initializer));
- (id<SkyprintKotlinx_coroutines_coreFlow>)discoverTimeoutMs:(int64_t)timeoutMs __attribute__((swift_name("discover(timeoutMs:)")));
@property (readonly) SkyprintTransportKind *kind __attribute__((swift_name("kind")));
@end


/**
 * Kiểm 1 host có mở cổng TCP không (REQ-003, DESIGN-003) -- dùng cho dò
 * subnet ([SubnetScanner]) lẫn "nhập IP tay rồi kiểm kết nối" của app.
 * Không phân biệt "host không tồn tại" và "có tồn tại nhưng không lắng
 * nghe cổng đó" -- cả 2 đều trả `false`, đúng nhu cầu discovery (chỉ cần
 * biết có in được không).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanProbe")))
@interface SkyprintLanProbe : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Kiểm 1 host có mở cổng TCP không (REQ-003, DESIGN-003) -- dùng cho dò
 * subnet ([SubnetScanner]) lẫn "nhập IP tay rồi kiểm kết nối" của app.
 * Không phân biệt "host không tồn tại" và "có tồn tại nhưng không lắng
 * nghe cổng đó" -- cả 2 đều trả `false`, đúng nhu cầu discovery (chỉ cần
 * biết có in được không).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)lanProbe __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintLanProbe *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)probeHost:(NSString *)host port:(int32_t)port timeoutMs:(int64_t)timeoutMs completionHandler:(void (^)(SkyprintBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("probe(host:port:timeoutMs:completionHandler:)")));
@end


/**
 * Lấy danh sách host trong mạng LAN hiện tại để [LanDiscovery] quét --
 * tách khỏi cách lấy IP/subnet thật (khác nhau theo nền tảng, xem
 * `createPlatformLocalSubnetProvider` androidMain) để phần thuật toán
 * quét ([SubnetScanner]) không phụ thuộc API mạng riêng của Android/iOS.
 */
__attribute__((swift_name("LocalSubnetProvider")))
@protocol SkyprintLocalSubnetProvider
@required

/** `null` nếu không xác định được subnet hiện tại (không có Wi-Fi/Ethernet). */
- (NSArray<NSString *> * _Nullable)currentSubnetHosts __attribute__((swift_name("currentSubnetHosts()")));
@end


/**
 * Quét đồng thời [hosts] bằng [probe] (mặc định [LanProbe.probe]), tối đa
 * [concurrency] kết nối song song (REQ-003, DESIGN-003: "32 kết nối song
 * song") -- tách [probe] thành tham số để test bằng hàm giả, không cần
 * mạng thật.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubnetScanner")))
@interface SkyprintSubnetScanner : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Quét đồng thời [hosts] bằng [probe] (mặc định [LanProbe.probe]), tối đa
 * [concurrency] kết nối song song (REQ-003, DESIGN-003: "32 kết nối song
 * song") -- tách [probe] thành tham số để test bằng hàm giả, không cần
 * mạng thật.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)subnetScanner __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintSubnetScanner *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)scanHosts:(NSArray<NSString *> *)hosts port:(int32_t)port timeoutMs:(int64_t)timeoutMs concurrency:(int32_t)concurrency probe:(id<SkyprintKotlinSuspendFunction3> _Nullable)probe completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("scan(hosts:port:timeoutMs:concurrency:probe:completionHandler:)")));
@end


/**
 * Bỏ dấu tiếng Việt về ASCII cho [com.dcorp.skyprint.core.model.TextMode.ASCII]
 * (REQ-001/REQ-002's req.md doc) -- máy in nhiệt rẻ tiền không đảm bảo hỗ
 * trợ UTF-8/codepage tiếng Việt trong ROM. Ký tự ngoài bảng và ngoài ASCII
 * in được (0x20..0x7E) bị thay bằng `?` thay vì lọt UTF-8 nhiều byte xuống
 * máy in (dễ ra chuỗi rác không đoán trước được), khớp acceptance criteria
 * của req.md.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AsciiFolding")))
@interface SkyprintAsciiFolding : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Bỏ dấu tiếng Việt về ASCII cho [com.dcorp.skyprint.core.model.TextMode.ASCII]
 * (REQ-001/REQ-002's req.md doc) -- máy in nhiệt rẻ tiền không đảm bảo hỗ
 * trợ UTF-8/codepage tiếng Việt trong ROM. Ký tự ngoài bảng và ngoài ASCII
 * in được (0x20..0x7E) bị thay bằng `?` thay vì lọt UTF-8 nhiều byte xuống
 * máy in (dễ ra chuỗi rác không đoán trước được), khớp acceptance criteria
 * của req.md.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)asciiFolding __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintAsciiFolding *shared __attribute__((swift_name("shared")));
- (NSString *)foldInput:(NSString *)input __attribute__((swift_name("fold(input:)")));
@end


/**
 * Lọc [ReceiptDocument] theo [PrinterCapabilities] (REQ-010) TRƯỚC khi đưa
 * vào [EscPosEncoder] -- máy in không có dao/két/còi/QR/mã vạch thì bỏ
 * hoặc thay thế phần tử tương ứng, không để [EscPosEncoder] phát byte lạ
 * xuống máy in không hiểu được (req.md acceptance: "không in ký tự rác").
 *
 * v1 chưa có QR raster fallback (cần [com.dcorp.skyprint.core.model.MonoBitmap]
 * từ REQ-002's rasterizer, hiện chưa cài) -- máy không hỗ trợ QR thì BỎ QUA
 * phần tử đó kèm cảnh báo, thay vì raster (DESIGN-010's "risk", theo dõi ở
 * REQ-002 xong mới nối lại).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CapabilityFilter")))
@interface SkyprintCapabilityFilter : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Lọc [ReceiptDocument] theo [PrinterCapabilities] (REQ-010) TRƯỚC khi đưa
 * vào [EscPosEncoder] -- máy in không có dao/két/còi/QR/mã vạch thì bỏ
 * hoặc thay thế phần tử tương ứng, không để [EscPosEncoder] phát byte lạ
 * xuống máy in không hiểu được (req.md acceptance: "không in ký tự rác").
 *
 * v1 chưa có QR raster fallback (cần [com.dcorp.skyprint.core.model.MonoBitmap]
 * từ REQ-002's rasterizer, hiện chưa cài) -- máy không hỗ trợ QR thì BỎ QUA
 * phần tử đó kèm cảnh báo, thay vì raster (DESIGN-010's "risk", theo dõi ở
 * REQ-002 xong mới nối lại).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)capabilityFilter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintCapabilityFilter *shared __attribute__((swift_name("shared")));
- (SkyprintKotlinPair<SkyprintReceiptDocument *, NSArray<NSString *> *> *)applyDocument:(SkyprintReceiptDocument *)document capabilities:(SkyprintPrinterCapabilities *)capabilities __attribute__((swift_name("apply(document:capabilities:)")));
@end


/**
 * Chuyển [ReceiptDocument] thành byte ESC/POS (REQ-001/DESIGN-001, mở rộng
 * nghiệp vụ POS ở DESIGN-010, chữ raster ở DESIGN-002).
 *
 * [TextMode.RASTER] gom các [Element.Text]/[Element.Row]/[Element.Divider]
 * LIÊN TIẾP thành một [com.dcorp.skyprint.core.raster.RasterBlock], gọi
 * [rasterizer] một lần cho cả nhóm (ít lệnh `GS v 0` hơn, in nhanh hơn so
 * với raster từng dòng riêng lẻ), rồi đóng gói bằng [RasterPacker]. Phần
 * tử khác (Cut/QrCode/Barcode/Drawer/Beep/Image) luôn ngắt nhóm đang gom dở.
 * [rasterizer] `null` -> [PrinterErrorCode.UNSUPPORTED_PLATFORM] ngay từ
 * đầu, không phát byte nào (chưa có bộ vẽ chữ thật theo nền tảng ở CODE-002,
 * xem CHANGELOG).
 *
 * [Element.Image] luôn dùng [RasterPacker] bất kể [mode] -- ảnh vốn đã là
 * bitmap sẵn, không cần "vẽ chữ" nên không phụ thuộc [rasterizer].
 *
 * [buzzerCommand]: chọn biến thể lệnh còi khớp máy in thật (DESIGN-010's
 * risk -- không có chuẩn chung giữa các hãng); không thuộc [PrinterCapabilities]
 * (đó là bộ lọc bật/tắt tính năng, không phải chọn cú pháp lệnh) nên truyền
 * trực tiếp vào đây, mặc định [BuzzerCommand.ESC_B] vì phổ biến nhất.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EscPosEncoder")))
@interface SkyprintEscPosEncoder : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Chuyển [ReceiptDocument] thành byte ESC/POS (REQ-001/DESIGN-001, mở rộng
 * nghiệp vụ POS ở DESIGN-010, chữ raster ở DESIGN-002).
 *
 * [TextMode.RASTER] gom các [Element.Text]/[Element.Row]/[Element.Divider]
 * LIÊN TIẾP thành một [com.dcorp.skyprint.core.raster.RasterBlock], gọi
 * [rasterizer] một lần cho cả nhóm (ít lệnh `GS v 0` hơn, in nhanh hơn so
 * với raster từng dòng riêng lẻ), rồi đóng gói bằng [RasterPacker]. Phần
 * tử khác (Cut/QrCode/Barcode/Drawer/Beep/Image) luôn ngắt nhóm đang gom dở.
 * [rasterizer] `null` -> [PrinterErrorCode.UNSUPPORTED_PLATFORM] ngay từ
 * đầu, không phát byte nào (chưa có bộ vẽ chữ thật theo nền tảng ở CODE-002,
 * xem CHANGELOG).
 *
 * [Element.Image] luôn dùng [RasterPacker] bất kể [mode] -- ảnh vốn đã là
 * bitmap sẵn, không cần "vẽ chữ" nên không phụ thuộc [rasterizer].
 *
 * [buzzerCommand]: chọn biến thể lệnh còi khớp máy in thật (DESIGN-010's
 * risk -- không có chuẩn chung giữa các hãng); không thuộc [PrinterCapabilities]
 * (đó là bộ lọc bật/tắt tính năng, không phải chọn cú pháp lệnh) nên truyền
 * trực tiếp vào đây, mặc định [BuzzerCommand.ESC_B] vì phổ biến nhất.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)escPosEncoder __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintEscPosEncoder *shared __attribute__((swift_name("shared")));
- (SkyprintKotlinByteArray *)encodeDocument:(SkyprintReceiptDocument *)document mode:(SkyprintTextMode *)mode buzzerCommand:(SkyprintBuzzerCommand *)buzzerCommand rasterizer:(id<SkyprintTextRasterizer> _Nullable)rasterizer __attribute__((swift_name("encode(document:mode:buzzerCommand:rasterizer:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol SkyprintKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface SkyprintKotlinEnum<E> : SkyprintBase <SkyprintKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SkyprintKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end


/**
 * Mã lỗi thống nhất giữa mọi transport và cả hai bản KMP/Dart (DESIGN-008,
 * xem bảng đầy đủ + [retryable] ở docs/architecture.md của repo skyprint).
 * Encoder/document (REQ-001) chỉ dùng [INVALID_DOCUMENT] và [INVALID_TEMPLATE]
 * -- các mã còn lại thuộc transport/queue (REQ-004..008), khai đủ ở đây để
 * component nào cũng tham chiếu cùng một enum, không rải rác định nghĩa lỗi
 * theo từng module.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterErrorCode")))
@interface SkyprintPrinterErrorCode : SkyprintKotlinEnum<SkyprintPrinterErrorCode *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Mã lỗi thống nhất giữa mọi transport và cả hai bản KMP/Dart (DESIGN-008,
 * xem bảng đầy đủ + [retryable] ở docs/architecture.md của repo skyprint).
 * Encoder/document (REQ-001) chỉ dùng [INVALID_DOCUMENT] và [INVALID_TEMPLATE]
 * -- các mã còn lại thuộc transport/queue (REQ-004..008), khai đủ ở đây để
 * component nào cũng tham chiếu cùng một enum, không rải rác định nghĩa lỗi
 * theo từng module.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintPrinterErrorCode *invalidDocument __attribute__((swift_name("invalidDocument")));
@property (class, readonly) SkyprintPrinterErrorCode *invalidTemplate __attribute__((swift_name("invalidTemplate")));
@property (class, readonly) SkyprintPrinterErrorCode *permissionRequired __attribute__((swift_name("permissionRequired")));
@property (class, readonly) SkyprintPrinterErrorCode *permissionDenied __attribute__((swift_name("permissionDenied")));
@property (class, readonly) SkyprintPrinterErrorCode *unsupportedPlatform __attribute__((swift_name("unsupportedPlatform")));
@property (class, readonly) SkyprintPrinterErrorCode *unsupportedDevice __attribute__((swift_name("unsupportedDevice")));
@property (class, readonly) SkyprintPrinterErrorCode *notFound __attribute__((swift_name("notFound")));
@property (class, readonly) SkyprintPrinterErrorCode *adapterOff __attribute__((swift_name("adapterOff")));
@property (class, readonly) SkyprintPrinterErrorCode *connectTimeout __attribute__((swift_name("connectTimeout")));
@property (class, readonly) SkyprintPrinterErrorCode *hostUnreachable __attribute__((swift_name("hostUnreachable")));
@property (class, readonly) SkyprintPrinterErrorCode *disconnected __attribute__((swift_name("disconnected")));
@property (class, readonly) SkyprintPrinterErrorCode *writeFailed __attribute__((swift_name("writeFailed")));
@property (class, readonly) SkyprintPrinterErrorCode *timeout __attribute__((swift_name("timeout")));
@property (class, readonly) SkyprintPrinterErrorCode *cancelled __attribute__((swift_name("cancelled")));
@property (class, readonly) SkyprintPrinterErrorCode *unknown __attribute__((swift_name("unknown")));
+ (SkyprintKotlinArray<SkyprintPrinterErrorCode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintPrinterErrorCode *> *entries __attribute__((swift_name("entries")));
@property (readonly) BOOL retryable __attribute__((swift_name("retryable")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface SkyprintKotlinThrowable : SkyprintBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (SkyprintKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface SkyprintKotlinException : SkyprintKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/** Ném khi encoder/template không thể tạo ra byte hợp lệ -- không phải lỗi transport. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterException")))
@interface SkyprintPrinterException : SkyprintKotlinException
- (instancetype)initWithCode:(SkyprintPrinterErrorCode *)code message:(NSString *)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(code:message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) SkyprintPrinterErrorCode *code __attribute__((swift_name("code")));
@end


/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanConfig")))
@interface SkyprintLanConfig : SkyprintBase
- (instancetype)initWithDefaultPort:(int32_t)defaultPort connectTimeoutMs:(int64_t)connectTimeoutMs writeTimeoutMs:(int64_t)writeTimeoutMs __attribute__((swift_name("init(defaultPort:connectTimeoutMs:writeTimeoutMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintLanConfig *)doCopyDefaultPort:(int32_t)defaultPort connectTimeoutMs:(int64_t)connectTimeoutMs writeTimeoutMs:(int64_t)writeTimeoutMs __attribute__((swift_name("doCopy(defaultPort:connectTimeoutMs:writeTimeoutMs:)")));

/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [defaultPort]: 9100 (JetDirect/RAW), cổng chuẩn de-facto cho máy in ESC/POS
 * qua LAN -- dùng khi [PrinterInfo.address] chỉ có host, không có `:port`.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t connectTimeoutMs __attribute__((swift_name("connectTimeoutMs")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) int64_t writeTimeoutMs __attribute__((swift_name("writeTimeoutMs")));
@end


/**
 * Transport LAN qua raw TCP (REQ-005, DESIGN-005) -- chạy được cả Android
 * và iOS vì dùng `ktor-network` (commonMain), không phải API riêng nền
 * tảng như REQ-004's USB.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LanPrinterTransport")))
@interface SkyprintLanPrinterTransport : SkyprintBase <SkyprintPrinterTransport>
- (instancetype)initWithConfig:(SkyprintLanConfig *)config __attribute__((swift_name("init(config:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openPrinter:(SkyprintPrinterInfo *)printer completionHandler:(void (^)(id<SkyprintPrinterConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(printer:completionHandler:)")));
@property (readonly) SkyprintTransportKind *kind __attribute__((swift_name("kind")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Align")))
@interface SkyprintAlign : SkyprintKotlinEnum<SkyprintAlign *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintAlign *left __attribute__((swift_name("left")));
@property (class, readonly) SkyprintAlign *center __attribute__((swift_name("center")));
@property (class, readonly) SkyprintAlign *right __attribute__((swift_name("right")));
+ (SkyprintKotlinArray<SkyprintAlign *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintAlign *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Loại mã vạch 1D hỗ trợ (REQ-010). [oldStyleSymbol] khác null -> dùng lệnh
 * ESC/POS cũ `GS k m d1..dk NUL`; null -> dùng lệnh mới `GS k m n d1..dn`
 * (chỉ CODE128 cần, vì phải mang tiền tố code-set `{A/{B/{C` trong data).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BarcodeType")))
@interface SkyprintBarcodeType : SkyprintKotlinEnum<SkyprintBarcodeType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Loại mã vạch 1D hỗ trợ (REQ-010). [oldStyleSymbol] khác null -> dùng lệnh
 * ESC/POS cũ `GS k m d1..dk NUL`; null -> dùng lệnh mới `GS k m n d1..dn`
 * (chỉ CODE128 cần, vì phải mang tiền tố code-set `{A/{B/{C` trong data).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintBarcodeType *upca __attribute__((swift_name("upca")));
@property (class, readonly) SkyprintBarcodeType *ean13 __attribute__((swift_name("ean13")));
@property (class, readonly) SkyprintBarcodeType *ean8 __attribute__((swift_name("ean8")));
@property (class, readonly) SkyprintBarcodeType *code39 __attribute__((swift_name("code39")));
@property (class, readonly) SkyprintBarcodeType *code128 __attribute__((swift_name("code128")));
+ (SkyprintKotlinArray<SkyprintBarcodeType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintBarcodeType *> *entries __attribute__((swift_name("entries")));
@end


/** Lệnh còi khác nhau giữa hãng máy in (DESIGN-010's risk) -- cấu hình theo máy thay vì đoán một chuẩn chung. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BuzzerCommand")))
@interface SkyprintBuzzerCommand : SkyprintKotlinEnum<SkyprintBuzzerCommand *>
+ (instancetype)alloc __attribute__((unavailable));

/** Lệnh còi khác nhau giữa hãng máy in (DESIGN-010's risk) -- cấu hình theo máy thay vì đoán một chuẩn chung. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintBuzzerCommand *escB __attribute__((swift_name("escB")));
@property (class, readonly) SkyprintBuzzerCommand *epsonA __attribute__((swift_name("epsonA")));
+ (SkyprintKotlinArray<SkyprintBuzzerCommand *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintBuzzerCommand *> *entries __attribute__((swift_name("entries")));
@end


/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Column")))
@interface SkyprintColumn : SkyprintBase
- (instancetype)initWithText:(NSString *)text weight:(int32_t)weight align:(SkyprintAlign *)align bold:(BOOL)bold __attribute__((swift_name("init(text:weight:align:bold:)"))) __attribute__((objc_designated_initializer));
- (SkyprintColumn *)doCopyText:(NSString *)text weight:(int32_t)weight align:(SkyprintAlign *)align bold:(BOOL)bold __attribute__((swift_name("doCopy(text:weight:align:bold:)")));

/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Một cột trong [Element.Row]. [weight] quyết định tỷ lệ bề rộng, tương tự flex-grow. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintAlign *align __attribute__((swift_name("align")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@property (readonly) int32_t weight __attribute__((swift_name("weight")));
@end


/**
 * Một phần tử trong [ReceiptDocument]. Tập hợp tối thiểu cho REQ-001 --
 * [Element.QrCode]/[Element.Image] khai interface theo DESIGN-001 nhưng nội
 * dung mã hoá byte thật của QR/ảnh raster nằm ở REQ-002 (raster)/REQ-010
 * (mã vạch, capabilities) khi các CODE đó lên; QrCode ở đây được cài đủ vì
 * nằm trong scope REQ-001 (không thuộc "Out of scope" của req.md).
 */
__attribute__((swift_name("Element")))
@protocol SkyprintElement
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementBarcode")))
@interface SkyprintElementBarcode : SkyprintBase <SkyprintElement>
- (instancetype)initWithData:(NSString *)data type:(SkyprintBarcodeType *)type heightDots:(int32_t)heightDots hri:(BOOL)hri align:(SkyprintAlign *)align __attribute__((swift_name("init(data:type:heightDots:hri:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementBarcode *)doCopyData:(NSString *)data type:(SkyprintBarcodeType *)type heightDots:(int32_t)heightDots hri:(BOOL)hri align:(SkyprintAlign *)align __attribute__((swift_name("doCopy(data:type:heightDots:hri:align:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintAlign *align __attribute__((swift_name("align")));
@property (readonly) NSString *data __attribute__((swift_name("data")));
@property (readonly) int32_t heightDots __attribute__((swift_name("heightDots")));
@property (readonly) BOOL hri __attribute__((swift_name("hri")));
@property (readonly) SkyprintBarcodeType *type __attribute__((swift_name("type")));
@end


/** Còi báo máy in bếp có phiếu mới. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementBeep")))
@interface SkyprintElementBeep : SkyprintBase <SkyprintElement>
- (instancetype)initWithTimes:(int32_t)times durationMs:(int32_t)durationMs __attribute__((swift_name("init(times:durationMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementBeep *)doCopyTimes:(int32_t)times durationMs:(int32_t)durationMs __attribute__((swift_name("doCopy(times:durationMs:)")));

/** Còi báo máy in bếp có phiếu mới. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Còi báo máy in bếp có phiếu mới. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Còi báo máy in bếp có phiếu mới. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t durationMs __attribute__((swift_name("durationMs")));
@property (readonly) int32_t times __attribute__((swift_name("times")));
@end


/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementCut")))
@interface SkyprintElementCut : SkyprintBase <SkyprintElement>
- (instancetype)initWithPartial:(BOOL)partial __attribute__((swift_name("init(partial:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementCut *)doCopyPartial:(BOOL)partial __attribute__((swift_name("doCopy(partial:)")));

/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** [partial]: cắt một phần (giấy còn dính 1 điểm, dễ xé) -- máy không có dao thay bằng feed qua [CapabilityFilter] (REQ-010). */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL partial __attribute__((swift_name("partial")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementDivider")))
@interface SkyprintElementDivider : SkyprintBase <SkyprintElement>
- (instancetype)initWithChar:(unichar)char_ __attribute__((swift_name("init(char:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementDivider *)doCopyChar:(unichar)char_ __attribute__((swift_name("doCopy(char:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=char) unichar char_ __attribute__((swift_name("char_")));
@end


/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementDrawer")))
@interface SkyprintElementDrawer : SkyprintBase <SkyprintElement>
- (instancetype)initWithPin:(int32_t)pin pulseMs:(int32_t)pulseMs __attribute__((swift_name("init(pin:pulseMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementDrawer *)doCopyPin:(int32_t)pin pulseMs:(int32_t)pulseMs __attribute__((swift_name("doCopy(pin:pulseMs:)")));

/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Mở két tiền (`ESC p`) -- không in giấy. [pin]: chân kết nối két (0 hoặc 1, tuỳ dây RJ11 đấu vào chân nào). */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t pin __attribute__((swift_name("pin")));
@property (readonly) int32_t pulseMs __attribute__((swift_name("pulseMs")));
@end


/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementFeed")))
@interface SkyprintElementFeed : SkyprintBase <SkyprintElement>
- (instancetype)initWithLines:(int32_t)lines __attribute__((swift_name("init(lines:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementFeed *)doCopyLines:(int32_t)lines __attribute__((swift_name("doCopy(lines:)")));

/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Feed [lines] dòng trắng. Giá trị âm coi như 0 -- clamp ở [EscPosCommands.feed], không ném lỗi ở đây vì đây chỉ là data class. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t lines __attribute__((swift_name("lines")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementImage")))
@interface SkyprintElementImage : SkyprintBase <SkyprintElement>
- (instancetype)initWithBitmap:(SkyprintMonoBitmap *)bitmap align:(SkyprintAlign *)align __attribute__((swift_name("init(bitmap:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementImage *)doCopyBitmap:(SkyprintMonoBitmap *)bitmap align:(SkyprintAlign *)align __attribute__((swift_name("doCopy(bitmap:align:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintAlign *align __attribute__((swift_name("align")));
@property (readonly) SkyprintMonoBitmap *bitmap __attribute__((swift_name("bitmap")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementQrCode")))
@interface SkyprintElementQrCode : SkyprintBase <SkyprintElement>
- (instancetype)initWithData:(NSString *)data moduleSize:(int32_t)moduleSize errorCorrection:(SkyprintQrErrorCorrection *)errorCorrection align:(SkyprintAlign *)align __attribute__((swift_name("init(data:moduleSize:errorCorrection:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementQrCode *)doCopyData:(NSString *)data moduleSize:(int32_t)moduleSize errorCorrection:(SkyprintQrErrorCorrection *)errorCorrection align:(SkyprintAlign *)align __attribute__((swift_name("doCopy(data:moduleSize:errorCorrection:align:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintAlign *align __attribute__((swift_name("align")));
@property (readonly) NSString *data __attribute__((swift_name("data")));
@property (readonly) SkyprintQrErrorCorrection *errorCorrection __attribute__((swift_name("errorCorrection")));
@property (readonly) int32_t moduleSize __attribute__((swift_name("moduleSize")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementRow")))
@interface SkyprintElementRow : SkyprintBase <SkyprintElement>
- (instancetype)initWithColumns:(NSArray<SkyprintColumn *> *)columns __attribute__((swift_name("init(columns:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementRow *)doCopyColumns:(NSArray<SkyprintColumn *> *)columns __attribute__((swift_name("doCopy(columns:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SkyprintColumn *> *columns __attribute__((swift_name("columns")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ElementText")))
@interface SkyprintElementText : SkyprintBase <SkyprintElement>
- (instancetype)initWithText:(NSString *)text style:(SkyprintTextStyle *)style __attribute__((swift_name("init(text:style:)"))) __attribute__((objc_designated_initializer));
- (SkyprintElementText *)doCopyText:(NSString *)text style:(SkyprintTextStyle *)style __attribute__((swift_name("doCopy(text:style:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintTextStyle *style __attribute__((swift_name("style")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@end


/** Ảnh 1-bit đã raster sẵn (REQ-002 tạo ra, REQ-001 chỉ cần biết hình dạng để đóng gói `GS v 0`). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MonoBitmap")))
@interface SkyprintMonoBitmap : SkyprintBase
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height bits:(SkyprintKotlinByteArray *)bits __attribute__((swift_name("init(width:height:bits:)"))) __attribute__((objc_designated_initializer));
- (SkyprintMonoBitmap *)doCopyWidth:(int32_t)width height:(int32_t)height bits:(SkyprintKotlinByteArray *)bits __attribute__((swift_name("doCopy(width:height:bits:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Ảnh 1-bit đã raster sẵn (REQ-002 tạo ra, REQ-001 chỉ cần biết hình dạng để đóng gói `GS v 0`). */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintKotlinByteArray *bits __attribute__((swift_name("bits")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/**
 * Khổ giấy máy in nhiệt phổ thông (DESIGN-001). [columns] là số ký tự Font A
 * chuẩn (12x24 dot), dùng để word-wrap/layout trước khi biết thật sự dùng
 * font cỡ nào; [dots] là bề rộng in được tính theo dot, dùng cho raster
 * (REQ-002) và QR.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PaperWidth")))
@interface SkyprintPaperWidth : SkyprintKotlinEnum<SkyprintPaperWidth *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Khổ giấy máy in nhiệt phổ thông (DESIGN-001). [columns] là số ký tự Font A
 * chuẩn (12x24 dot), dùng để word-wrap/layout trước khi biết thật sự dùng
 * font cỡ nào; [dots] là bề rộng in được tính theo dot, dùng cho raster
 * (REQ-002) và QR.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintPaperWidth *mm58 __attribute__((swift_name("mm58")));
@property (class, readonly) SkyprintPaperWidth *mm80 __attribute__((swift_name("mm80")));
+ (SkyprintKotlinArray<SkyprintPaperWidth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintPaperWidth *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t columns __attribute__((swift_name("columns")));
@property (readonly) int32_t dots __attribute__((swift_name("dots")));
@end


/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterCapabilities")))
@interface SkyprintPrinterCapabilities : SkyprintBase
- (instancetype)initWithCutter:(BOOL)cutter drawer:(BOOL)drawer buzzer:(BOOL)buzzer qr:(BOOL)qr barcode:(BOOL)barcode inverse:(BOOL)inverse buzzerCommand:(SkyprintBuzzerCommand *)buzzerCommand __attribute__((swift_name("init(cutter:drawer:buzzer:qr:barcode:inverse:buzzerCommand:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SkyprintPrinterCapabilitiesCompanion *companion __attribute__((swift_name("companion")));
- (SkyprintPrinterCapabilities *)doCopyCutter:(BOOL)cutter drawer:(BOOL)drawer buzzer:(BOOL)buzzer qr:(BOOL)qr barcode:(BOOL)barcode inverse:(BOOL)inverse buzzerCommand:(SkyprintBuzzerCommand *)buzzerCommand __attribute__((swift_name("doCopy(cutter:drawer:buzzer:qr:barcode:inverse:buzzerCommand:)")));

/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Năng lực phần cứng một máy in khai báo (REQ-010). Mặc định không tham số
 * bật hết TRỪ [drawer]/[buzzer] -- đúng theo precondition của req.md
 * ("App khai PrinterCapabilities cho từng máy in; mặc định: bật hết trừ
 * drawer/buzzer") vì phần lớn máy in KHÔNG có 2 phần cứng này gắn kèm, còn
 * cutter/qr/barcode/inverse gần như luôn có trên máy in nhiệt hiện đại.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL barcode __attribute__((swift_name("barcode")));
@property (readonly) BOOL buzzer __attribute__((swift_name("buzzer")));
@property (readonly) SkyprintBuzzerCommand *buzzerCommand __attribute__((swift_name("buzzerCommand")));
@property (readonly) BOOL cutter __attribute__((swift_name("cutter")));
@property (readonly) BOOL drawer __attribute__((swift_name("drawer")));
@property (readonly) BOOL inverse __attribute__((swift_name("inverse")));
@property (readonly) BOOL qr __attribute__((swift_name("qr")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterCapabilities.Companion")))
@interface SkyprintPrinterCapabilitiesCompanion : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintPrinterCapabilitiesCompanion *shared __attribute__((swift_name("shared")));

/** Dùng khi biết chắc máy in có đủ mọi phần cứng (test, hoặc máy in cao cấp đã kiểm chứng). */
@property (readonly) SkyprintPrinterCapabilities *ALL __attribute__((swift_name("ALL")));
@end


/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrinterInfo")))
@interface SkyprintPrinterInfo : SkyprintBase
- (instancetype)initWithId:(NSString *)id name:(NSString *)name kind:(SkyprintTransportKind *)kind address:(NSString *)address extras:(NSDictionary<NSString *, NSString *> *)extras __attribute__((swift_name("init(id:name:kind:address:extras:)"))) __attribute__((objc_designated_initializer));
- (SkyprintPrinterInfo *)doCopyId:(NSString *)id name:(NSString *)name kind:(SkyprintTransportKind *)kind address:(NSString *)address extras:(NSDictionary<NSString *, NSString *> *)extras __attribute__((swift_name("doCopy(id:name:kind:address:extras:)")));

/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [id] ổn định qua nhiều lần mở app (DESIGN-003): `usb:<vendorId>:<productId>`,
 * `bt:<MAC>`, `ble:<MAC|CB-UUID>`, `lan:<host>:<port>` -- KHÔNG dùng tên
 * thiết bị hệ điều hành trả về (đổi mỗi lần cắm lại USB).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *address __attribute__((swift_name("address")));
@property (readonly) NSDictionary<NSString *, NSString *> *extras __attribute__((swift_name("extras")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) SkyprintTransportKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QrErrorCorrection")))
@interface SkyprintQrErrorCorrection : SkyprintKotlinEnum<SkyprintQrErrorCorrection *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintQrErrorCorrection *l __attribute__((swift_name("l")));
@property (class, readonly) SkyprintQrErrorCorrection *m __attribute__((swift_name("m")));
@property (class, readonly) SkyprintQrErrorCorrection *q __attribute__((swift_name("q")));
@property (class, readonly) SkyprintQrErrorCorrection *h __attribute__((swift_name("h")));
+ (SkyprintKotlinArray<SkyprintQrErrorCorrection *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintQrErrorCorrection *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t code __attribute__((swift_name("code")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReceiptDocument")))
@interface SkyprintReceiptDocument : SkyprintBase
- (instancetype)initWithPaper:(SkyprintPaperWidth *)paper elements:(NSArray<id<SkyprintElement>> *)elements __attribute__((swift_name("init(paper:elements:)"))) __attribute__((objc_designated_initializer));
- (SkyprintReceiptDocument *)doCopyPaper:(SkyprintPaperWidth *)paper elements:(NSArray<id<SkyprintElement>> *)elements __attribute__((swift_name("doCopy(paper:elements:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<id<SkyprintElement>> *elements __attribute__((swift_name("elements")));
@property (readonly) SkyprintPaperWidth *paper __attribute__((swift_name("paper")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TextMode")))
@interface SkyprintTextMode : SkyprintKotlinEnum<SkyprintTextMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintTextMode *ascii __attribute__((swift_name("ascii")));
@property (class, readonly) SkyprintTextMode *raster __attribute__((swift_name("raster")));
+ (SkyprintKotlinArray<SkyprintTextMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintTextMode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TextStyle")))
@interface SkyprintTextStyle : SkyprintBase
- (instancetype)initWithAlign:(SkyprintAlign *)align bold:(BOOL)bold width:(int32_t)width height:(int32_t)height inverse:(BOOL)inverse underline:(BOOL)underline __attribute__((swift_name("init(align:bold:width:height:inverse:underline:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTextStyle *)doCopyAlign:(SkyprintAlign *)align bold:(BOOL)bold width:(int32_t)width height:(int32_t)height inverse:(BOOL)inverse underline:(BOOL)underline __attribute__((swift_name("doCopy(align:bold:width:height:inverse:underline:)")));

/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [width]/[height]: 1..8, khớp 2 nibble độc lập của `GS ! n` (REQ-010 --
 * máy in ESC/POS cho phép phóng ngang/dọc riêng, không bắt buộc bằng nhau
 * như `size` gộp một chỉ số ở bản REQ-001 ban đầu). [inverse]: chữ trắng
 * nền đen (`GS B 1`), dùng cho phiếu huỷ món nổi bật (REQ-010's req.md).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintAlign *align __attribute__((swift_name("align")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) BOOL inverse __attribute__((swift_name("inverse")));
@property (readonly) BOOL underline __attribute__((swift_name("underline")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/**
 * Model tối thiểu từ DESIGN-003 (discovery) -- đưa vào đây SỚM vì REQ-008's
 * [com.dcorp.skyprint.core.transport.PrinterTransport] cần kiểu này để khai
 * `open(printer: PrinterInfo)`. Logic tìm máy in thật (quét USB/BLE/LAN/bonded
 * Bluetooth) CHƯA cài -- đó vẫn là REQ-003, chưa tới lượt code.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransportKind")))
@interface SkyprintTransportKind : SkyprintKotlinEnum<SkyprintTransportKind *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Model tối thiểu từ DESIGN-003 (discovery) -- đưa vào đây SỚM vì REQ-008's
 * [com.dcorp.skyprint.core.transport.PrinterTransport] cần kiểu này để khai
 * `open(printer: PrinterInfo)`. Logic tìm máy in thật (quét USB/BLE/LAN/bonded
 * Bluetooth) CHƯA cài -- đó vẫn là REQ-003, chưa tới lượt code.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintTransportKind *usb __attribute__((swift_name("usb")));
@property (class, readonly) SkyprintTransportKind *lan __attribute__((swift_name("lan")));
@property (class, readonly) SkyprintTransportKind *btClassic __attribute__((swift_name("btClassic")));
@property (class, readonly) SkyprintTransportKind *ble __attribute__((swift_name("ble")));
+ (SkyprintKotlinArray<SkyprintTransportKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintTransportKind *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Chuyển ảnh xám (grayscale, 1 byte/pixel, 0=đen 255=trắng) thành [MonoBitmap]
 * 1-bit bằng ngưỡng đơn giản (REQ-002). Không dùng Floyd-Steinberg hay
 * thuật toán dither nâng cao ở v1 -- text render ra glyph có cạnh rõ, không
 * cần khử răng cưa bằng dither; chỉ ảnh logo mới cần, để sau khi có nhu cầu
 * thật (không đoán trước).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Dither")))
@interface SkyprintDither : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Chuyển ảnh xám (grayscale, 1 byte/pixel, 0=đen 255=trắng) thành [MonoBitmap]
 * 1-bit bằng ngưỡng đơn giản (REQ-002). Không dùng Floyd-Steinberg hay
 * thuật toán dither nâng cao ở v1 -- text render ra glyph có cạnh rõ, không
 * cần khử răng cưa bằng dither; chỉ ảnh logo mới cần, để sau khi có nhu cầu
 * thật (không đoán trước).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)dither __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintDither *shared __attribute__((swift_name("shared")));
- (SkyprintMonoBitmap *)thresholdGray:(SkyprintKotlinByteArray *)gray width:(int32_t)width height:(int32_t)height level:(int32_t)level __attribute__((swift_name("threshold(gray:width:height:level:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterBlock")))
@interface SkyprintRasterBlock : SkyprintBase
- (instancetype)initWithLines:(NSArray<SkyprintRasterLine *> *)lines __attribute__((swift_name("init(lines:)"))) __attribute__((objc_designated_initializer));
- (SkyprintRasterBlock *)doCopyLines:(NSArray<SkyprintRasterLine *> *)lines __attribute__((swift_name("doCopy(lines:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SkyprintRasterLine *> *lines __attribute__((swift_name("lines")));
@end


/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterLine")))
@interface SkyprintRasterLine : SkyprintBase
- (instancetype)initWithSpans:(NSArray<SkyprintRasterSpan *> *)spans align:(SkyprintAlign *)align __attribute__((swift_name("init(spans:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintRasterLine *)doCopySpans:(NSArray<SkyprintRasterSpan *> *)spans align:(SkyprintAlign *)align __attribute__((swift_name("doCopy(spans:align:)")));

/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [Element.Row]/[Element.Divider] được [EscPosEncoder] quy về MỘT [RasterSpan]
 * đã canh cột sẵn bằng [com.dcorp.skyprint.core.encode.LayoutEngine] (tái
 * dùng logic ASCII, không viết lại) -- vì vậy [TextRasterizer] cần vẽ bằng
 * font đơn cách (monospace) cho các dòng này để giữ thẳng cột; [Element.Text]
 * thì không bắt buộc.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintAlign *align __attribute__((swift_name("align")));
@property (readonly) NSArray<SkyprintRasterSpan *> *spans __attribute__((swift_name("spans")));
@end


/**
 * Đóng gói [MonoBitmap] thành lệnh ESC/POS `GS v 0` (REQ-002, DESIGN-002).
 * Chia theo dải [bandHeight] dòng dot -- máy in nhiệt rẻ tiền có buffer nhỏ,
 * gửi nguyên ảnh cao hàng nghìn dot trong 1 lệnh dễ tràn buffer/treo máy;
 * nhiều lệnh `GS v 0` liên tiếp (mỗi lệnh 1 dải) an toàn hơn dù cùng tổng
 * dữ liệu.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterPacker")))
@interface SkyprintRasterPacker : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Đóng gói [MonoBitmap] thành lệnh ESC/POS `GS v 0` (REQ-002, DESIGN-002).
 * Chia theo dải [bandHeight] dòng dot -- máy in nhiệt rẻ tiền có buffer nhỏ,
 * gửi nguyên ảnh cao hàng nghìn dot trong 1 lệnh dễ tràn buffer/treo máy;
 * nhiều lệnh `GS v 0` liên tiếp (mỗi lệnh 1 dải) an toàn hơn dù cùng tổng
 * dữ liệu.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)rasterPacker __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintRasterPacker *shared __attribute__((swift_name("shared")));
- (SkyprintKotlinByteArray *)toGsV0Bitmap:(SkyprintMonoBitmap *)bitmap bandHeight:(int32_t)bandHeight __attribute__((swift_name("toGsV0(bitmap:bandHeight:)")));
@end


/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RasterSpan")))
@interface SkyprintRasterSpan : SkyprintBase
- (instancetype)initWithText:(NSString *)text bold:(BOOL)bold underline:(BOOL)underline inverse:(BOOL)inverse widthScale:(int32_t)widthScale heightScale:(int32_t)heightScale __attribute__((swift_name("init(text:bold:underline:inverse:widthScale:heightScale:)"))) __attribute__((objc_designated_initializer));
- (SkyprintRasterSpan *)doCopyText:(NSString *)text bold:(BOOL)bold underline:(BOOL)underline inverse:(BOOL)inverse widthScale:(int32_t)widthScale heightScale:(int32_t)heightScale __attribute__((swift_name("doCopy(text:bold:underline:inverse:widthScale:heightScale:)")));

/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Một đoạn chữ cùng kiểu trong [RasterLine] (REQ-002). [widthScale]/[heightScale]
 * khớp [com.dcorp.skyprint.core.model.TextStyle.width]/`.height` (1..8).
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) int32_t heightScale __attribute__((swift_name("heightScale")));
@property (readonly) BOOL inverse __attribute__((swift_name("inverse")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@property (readonly) BOOL underline __attribute__((swift_name("underline")));
@property (readonly) int32_t widthScale __attribute__((swift_name("widthScale")));
@end


/**
 * Vẽ chữ thành ảnh 1-bit theo nền tảng (REQ-002) -- Android dùng `Canvas`/
 * `StaticLayout`, iOS dùng `CoreText`, Flutter dùng `dart:ui`. CHƯA cài ở
 * CODE-002 (v1 mới có contract + [EscPosEncoder] nối vào qua interface này,
 * đã kiểm bằng rasterizer giả trong test) -- 3 cài đặt thật cần toolchain
 * Android/iOS riêng, theo dõi tiếp ở CODE-002b/CODE-002c.
 */
__attribute__((swift_name("TextRasterizer")))
@protocol SkyprintTextRasterizer
@required
- (SkyprintMonoBitmap *)renderBlock:(SkyprintRasterBlock *)block widthDots:(int32_t)widthDots __attribute__((swift_name("render(block:widthDots:)")));
@end


/**
 * Tuần tự hoá lệnh in theo máy in, có retry/timeout/mã lỗi thống nhất
 * (REQ-008, DESIGN-008). Facade [PrinterService] (chưa cài -- gồm cả
 * encode/template) sẽ gọi [print] với byte đã dựng sẵn từ REQ-001/002/009.
 *
 * KHÔNG bắt [CancellationException] thành [PrintResult.Failure] -- app tự
 * huỷ job (`Job.cancel()`) thì lời gọi [print] tự huỷ theo (coroutine
 * convention chuẩn), không giả vờ trả về kết quả bình thường. "Transport
 * đóng sạch" khi bị huỷ (req.md's alternate flow) vẫn đảm bảo vì [attemptOnce]
 * đóng connection trong ngữ cảnh [NonCancellable].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrintQueue")))
@interface SkyprintPrintQueue : SkyprintBase
- (instancetype)initWithTransports:(NSArray<id<SkyprintPrinterTransport>> *)transports policy:(SkyprintRetryPolicy *)policy __attribute__((swift_name("init(transports:policy:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)printPrinter:(SkyprintPrinterInfo *)printer bytes:(SkyprintKotlinByteArray *)bytes completionHandler:(void (^)(id<SkyprintPrintResult> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("print(printer:bytes:completionHandler:)")));
@end


/** Kết quả một lệnh in (REQ-008) -- KMP và Dart cùng hình dạng này để app dùng chung logic xử lý kết quả. */
__attribute__((swift_name("PrintResult")))
@protocol SkyprintPrintResult
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrintResultFailure")))
@interface SkyprintPrintResultFailure : SkyprintBase <SkyprintPrintResult>
- (instancetype)initWithCode:(SkyprintPrinterErrorCode *)code message:(NSString *)message __attribute__((swift_name("init(code:message:)"))) __attribute__((objc_designated_initializer));
- (SkyprintPrintResultFailure *)doCopyCode:(SkyprintPrinterErrorCode *)code message:(NSString *)message __attribute__((swift_name("doCopy(code:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintPrinterErrorCode *code __attribute__((swift_name("code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrintResultSuccess")))
@interface SkyprintPrintResultSuccess : SkyprintBase <SkyprintPrintResult>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)success __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintPrintResultSuccess *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Kết nối đang mở tới MỘT máy in (REQ-008, DESIGN-008). Vòng đời do
 * [PrintQueue] quản -- gọi [write] đúng 1 lần rồi luôn [close], kể cả khi
 * [write] lỗi.
 */
__attribute__((swift_name("PrinterConnection")))
@protocol SkyprintPrinterConnection
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("close(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)writeBytes:(SkyprintKotlinByteArray *)bytes completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("write(bytes:completionHandler:)")));
@end


/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RetryPolicy")))
@interface SkyprintRetryPolicy : SkyprintBase
- (instancetype)initWithMaxRetries:(int32_t)maxRetries backoffMs:(NSArray<SkyprintLong *> *)backoffMs jobTimeoutMs:(int64_t)jobTimeoutMs __attribute__((swift_name("init(maxRetries:backoffMs:jobTimeoutMs:)"))) __attribute__((objc_designated_initializer));
- (SkyprintRetryPolicy *)doCopyMaxRetries:(int32_t)maxRetries backoffMs:(NSArray<SkyprintLong *> *)backoffMs jobTimeoutMs:(int64_t)jobTimeoutMs __attribute__((swift_name("doCopy(maxRetries:backoffMs:jobTimeoutMs:)")));

/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * [maxRetries]: số lần thử LẠI sau lần đầu (tổng số lần thử = maxRetries + 1).
 * [backoffMs]: thời gian chờ trước mỗi lần thử lại, theo thứ tự; hết danh
 * sách thì lặp lại giá trị cuối. [jobTimeoutMs]: tổng thời gian tối đa cho
 * CẢ job (gồm mọi lần retry) -- vượt quá thì huỷ và trả [PrinterErrorCode.TIMEOUT].
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SkyprintLong *> *backoffMs __attribute__((swift_name("backoffMs")));
@property (readonly) int64_t jobTimeoutMs __attribute__((swift_name("jobTimeoutMs")));
@property (readonly) int32_t maxRetries __attribute__((swift_name("maxRetries")));
@end


/**
 * Điều kiện `if` trong mẫu (DESIGN-009). Ngữ pháp CỐ Ý tối giản, không có
 * dấu ngoặc, không gọi hàm -- an toàn, dễ kiểm, đủ cho nghiệp vụ hoá đơn:
 *
 * ```
 * cond := term (('&&'|'||') term)*      -- trái sang phải, không phân biệt độ ưu tiên
 * term := '!'? path (op literal)?
 * op   := '==' | '!=' | '>' | '>=' | '<' | '<='
 * ```
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConditionEvaluator")))
@interface SkyprintConditionEvaluator : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Điều kiện `if` trong mẫu (DESIGN-009). Ngữ pháp CỐ Ý tối giản, không có
 * dấu ngoặc, không gọi hàm -- an toàn, dễ kiểm, đủ cho nghiệp vụ hoá đơn:
 *
 * ```
 * cond := term (('&&'|'||') term)*      -- trái sang phải, không phân biệt độ ưu tiên
 * term := '!'? path (op literal)?
 * op   := '==' | '!=' | '>' | '>=' | '<' | '<='
 * ```
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)conditionEvaluator __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintConditionEvaluator *shared __attribute__((swift_name("shared")));
- (BOOL)evaluateScope:(SkyprintScope *)scope expr:(NSString *)expr __attribute__((swift_name("evaluate(scope:expr:)")));
@end


/**
 * Bộ định dạng `{{path | tên | tên:'tham số'}}` (DESIGN-009). Đăng ký cố
 * định, KHÔNG cho mẫu tự định nghĩa formatter mới (an toàn: mẫu chỉ dùng
 * dữ liệu app cấp + phép biến đổi đã kiểm soát, không chạy code tuỳ ý).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Formatters")))
@interface SkyprintFormatters : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Bộ định dạng `{{path | tên | tên:'tham số'}}` (DESIGN-009). Đăng ký cố
 * định, KHÔNG cho mẫu tự định nghĩa formatter mới (an toàn: mẫu chỉ dùng
 * dữ liệu app cấp + phép biến đổi đã kiểm soát, không chạy code tuỳ ý).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)formatters __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintFormatters *shared __attribute__((swift_name("shared")));
- (id<SkyprintTemplateValue>)applyName:(NSString *)name arg:(NSString * _Nullable)arg value:(id<SkyprintTemplateValue>)value money:(SkyprintMoneyFormat *)money __attribute__((swift_name("apply(name:arg:value:money:)")));
@end


/** App cấp bitmap cho `{{...}}` trong `Element.Image.source` -- engine không tự tải ảnh qua mạng (DESIGN-009). */
__attribute__((swift_name("ImageResolver")))
@protocol SkyprintImageResolver
@required
- (SkyprintMonoBitmap * _Nullable)resolveSource:(NSString *)source __attribute__((swift_name("resolve(source:)")));
@end


/**
 * Thay `{{ path | fmt | fmt2:'arg' }}` trong chuỗi mẫu bằng giá trị thật
 * (DESIGN-009). Văn bản ngoài `{{...}}` giữ nguyên; nhiều placeholder
 * trong cùng chuỗi được nối lại.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Interpolator")))
@interface SkyprintInterpolator : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Thay `{{ path | fmt | fmt2:'arg' }}` trong chuỗi mẫu bằng giá trị thật
 * (DESIGN-009). Văn bản ngoài `{{...}}` giữ nguyên; nhiều placeholder
 * trong cùng chuỗi được nối lại.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)interpolator __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintInterpolator *shared __attribute__((swift_name("shared")));
- (NSString *)interpolateScope:(SkyprintScope *)scope template:(NSString *)template_ money:(SkyprintMoneyFormat *)money __attribute__((swift_name("interpolate(scope:template:money:)")));

/** [path] không có `|` -- trả giá trị thô đã resolve (dùng khi cả biểu thức, không phải chuỗi có chữ bao quanh, chỉ là 1 path -- ví dụ điều kiện `if`). */
- (id<SkyprintTemplateValue>)resolveValueScope:(SkyprintScope *)scope path:(NSString *)path __attribute__((swift_name("resolveValue(scope:path:)")));
@end


/** Cấu hình tiền tệ cho formatter `money` (DESIGN-009's risk -- mặc định khớp VND minor=1/100). */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MoneyFormat")))
@interface SkyprintMoneyFormat : SkyprintBase
- (instancetype)initWithMinorUnits:(int32_t)minorUnits thousandsSeparator:(NSString *)thousandsSeparator suffix:(NSString *)suffix __attribute__((swift_name("init(minorUnits:thousandsSeparator:suffix:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SkyprintMoneyFormatCompanion *companion __attribute__((swift_name("companion")));
- (SkyprintMoneyFormat *)doCopyMinorUnits:(int32_t)minorUnits thousandsSeparator:(NSString *)thousandsSeparator suffix:(NSString *)suffix __attribute__((swift_name("doCopy(minorUnits:thousandsSeparator:suffix:)")));

/** Cấu hình tiền tệ cho formatter `money` (DESIGN-009's risk -- mặc định khớp VND minor=1/100). */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Cấu hình tiền tệ cho formatter `money` (DESIGN-009's risk -- mặc định khớp VND minor=1/100). */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Cấu hình tiền tệ cho formatter `money` (DESIGN-009's risk -- mặc định khớp VND minor=1/100). */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t minorUnits __attribute__((swift_name("minorUnits")));
@property (readonly) NSString *suffix __attribute__((swift_name("suffix")));
@property (readonly) NSString *thousandsSeparator __attribute__((swift_name("thousandsSeparator")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MoneyFormat.Companion")))
@interface SkyprintMoneyFormatCompanion : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintMoneyFormatCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SkyprintMoneyFormat *VND __attribute__((swift_name("VND")));
@end


/**
 * Đọc giá trị theo path kiểu `a.b.c`, `items[0].name`, hoặc biến vòng lặp
 * `it.name`/`$index` (DESIGN-009). Không throw khi thiếu -- trả [TemplateValue.Null],
 * đúng "Alternate flow" của req.md ("biến thiếu trong dữ liệu -> in chuỗi
 * rỗng/cảnh báo, không huỷ lệnh in").
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PathResolver")))
@interface SkyprintPathResolver : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Đọc giá trị theo path kiểu `a.b.c`, `items[0].name`, hoặc biến vòng lặp
 * `it.name`/`$index` (DESIGN-009). Không throw khi thiếu -- trả [TemplateValue.Null],
 * đúng "Alternate flow" của req.md ("biến thiếu trong dữ liệu -> in chuỗi
 * rỗng/cảnh báo, không huỷ lệnh in").
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pathResolver __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintPathResolver *shared __attribute__((swift_name("shared")));
- (id<SkyprintTemplateValue>)resolveScope:(SkyprintScope *)scope path:(NSString *)path __attribute__((swift_name("resolve(scope:path:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenderOptions")))
@interface SkyprintRenderOptions : SkyprintBase
- (instancetype)initWithMoney:(SkyprintMoneyFormat *)money paper:(SkyprintPaperWidth * _Nullable)paper images:(id<SkyprintImageResolver> _Nullable)images __attribute__((swift_name("init(money:paper:images:)"))) __attribute__((objc_designated_initializer));
- (SkyprintRenderOptions *)doCopyMoney:(SkyprintMoneyFormat *)money paper:(SkyprintPaperWidth * _Nullable)paper images:(id<SkyprintImageResolver> _Nullable)images __attribute__((swift_name("doCopy(money:paper:images:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<SkyprintImageResolver> _Nullable images __attribute__((swift_name("images")));
@property (readonly) SkyprintMoneyFormat *money __attribute__((swift_name("money")));
@property (readonly) SkyprintPaperWidth * _Nullable paper __attribute__((swift_name("paper")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RenderResult")))
@interface SkyprintRenderResult : SkyprintBase
- (instancetype)initWithDocument:(SkyprintReceiptDocument *)document warnings:(NSArray<SkyprintTemplateIssue *> *)warnings __attribute__((swift_name("init(document:warnings:)"))) __attribute__((objc_designated_initializer));
- (SkyprintRenderResult *)doCopyDocument:(SkyprintReceiptDocument *)document warnings:(NSArray<SkyprintTemplateIssue *> *)warnings __attribute__((swift_name("doCopy(document:warnings:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SkyprintReceiptDocument *document __attribute__((swift_name("document")));
@property (readonly) NSArray<SkyprintTemplateIssue *> *warnings __attribute__((swift_name("warnings")));
@end


/**
 * Kiểm mọi path tham chiếu trong [Template] có thuộc [TemplateSchema.paths]
 * không -- chạy lúc LƯU mẫu (req.md: "chặn ngay lúc Lưu, báo đúng tên biến"),
 * không đợi tới lúc in mới phát hiện thiếu/sai tên biến.
 *
 * Biến vòng lặp (`it`, `as`-alias, `$index`/`$first`/`$last`) không kiểm sâu
 * ở v1 -- schema không mô tả kiểu phần tử mảng, chỉ kiểm path đó THUỘC một
 * `each` hợp lệ (chính `each` vẫn được kiểm như path bình thường).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SchemaValidator")))
@interface SkyprintSchemaValidator : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Kiểm mọi path tham chiếu trong [Template] có thuộc [TemplateSchema.paths]
 * không -- chạy lúc LƯU mẫu (req.md: "chặn ngay lúc Lưu, báo đúng tên biến"),
 * không đợi tới lúc in mới phát hiện thiếu/sai tên biến.
 *
 * Biến vòng lặp (`it`, `as`-alias, `$index`/`$first`/`$last`) không kiểm sâu
 * ở v1 -- schema không mô tả kiểu phần tử mảng, chỉ kiểm path đó THUỘC một
 * `each` hợp lệ (chính `each` vẫn được kiểm như path bình thường).
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)schemaValidator __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintSchemaValidator *shared __attribute__((swift_name("shared")));
- (NSArray<SkyprintTemplateIssue *> *)validateTemplate:(SkyprintTemplate *)template_ schema:(SkyprintTemplateSchema *)schema __attribute__((swift_name("validate(template:schema:)")));
@end


/**
 * Ngữ cảnh resolve path (DESIGN-009) -- [bindings] là biến vòng lặp
 * (`it`, `m`, `$index`, `$first`, `$last`...) che (shadow) field cùng tên
 * ở [root] khi segment đầu của path trùng tên biến; path không khớp biến
 * nào thì resolve tiếp từ [root].
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Scope")))
@interface SkyprintScope : SkyprintBase
@property (class, readonly, getter=companion) SkyprintScopeCompanion *companion __attribute__((swift_name("companion")));
- (SkyprintScope *)bindPairs:(SkyprintKotlinArray<SkyprintKotlinPair<NSString *, id<SkyprintTemplateValue>> *> *)pairs __attribute__((swift_name("bind(pairs:)")));
@property (readonly) id<SkyprintTemplateValue> root __attribute__((swift_name("root")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Scope.Companion")))
@interface SkyprintScopeCompanion : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintScopeCompanion *shared __attribute__((swift_name("shared")));
- (SkyprintScope *)rootData:(id<SkyprintTemplateValue>)data __attribute__((swift_name("root(data:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Template")))
@interface SkyprintTemplate : SkyprintBase
- (instancetype)initWithId:(NSString *)id version:(int32_t)version documentType:(NSString *)documentType paper:(NSString * _Nullable)paper elements:(NSArray<SkyprintTemplateNode *> *)elements __attribute__((swift_name("init(id:version:documentType:paper:elements:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplate *)doCopyId:(NSString *)id version:(int32_t)version documentType:(NSString *)documentType paper:(NSString * _Nullable)paper elements:(NSArray<SkyprintTemplateNode *> *)elements __attribute__((swift_name("doCopy(id:version:documentType:paper:elements:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *documentType __attribute__((swift_name("documentType")));
@property (readonly) NSArray<SkyprintTemplateNode *> *elements __attribute__((swift_name("elements")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable paper __attribute__((swift_name("paper")));
@property (readonly) int32_t version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateColumn")))
@interface SkyprintTemplateColumn : SkyprintBase
- (instancetype)initWithText:(NSString *)text weight:(int32_t)weight align:(NSString *)align bold:(BOOL)bold __attribute__((swift_name("init(text:weight:align:bold:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateColumn *)doCopyText:(NSString *)text weight:(int32_t)weight align:(NSString *)align bold:(BOOL)bold __attribute__((swift_name("doCopy(text:weight:align:bold:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *align __attribute__((swift_name("align")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) NSString *text __attribute__((swift_name("text")));
@property (readonly) int32_t weight __attribute__((swift_name("weight")));
@end


/**
 * Ghép [Template] (đã parse) với dữ liệu chứng từ thành [ReceiptDocument]
 * (REQ-009, DESIGN-009). [validate] chạy TRƯỚC lúc lưu mẫu (chặn biến sai
 * ngay, không đợi tới lúc in); [render] chạy MỖI LẦN in.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateEngine")))
@interface SkyprintTemplateEngine : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Ghép [Template] (đã parse) với dữ liệu chứng từ thành [ReceiptDocument]
 * (REQ-009, DESIGN-009). [validate] chạy TRƯỚC lúc lưu mẫu (chặn biến sai
 * ngay, không đợi tới lúc in); [render] chạy MỖI LẦN in.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)templateEngine __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintTemplateEngine *shared __attribute__((swift_name("shared")));
- (SkyprintRenderResult *)renderTemplate:(SkyprintTemplate *)template_ data:(id<SkyprintTemplateValue>)data options:(SkyprintRenderOptions *)options __attribute__((swift_name("render(template:data:options:)")));
- (NSArray<SkyprintTemplateIssue *> *)validateTemplate:(SkyprintTemplate *)template_ schema:(SkyprintTemplateSchema *)schema __attribute__((swift_name("validate(template:schema:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateErrorCode")))
@interface SkyprintTemplateErrorCode : SkyprintKotlinEnum<SkyprintTemplateErrorCode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SkyprintTemplateErrorCode *invalidTemplate __attribute__((swift_name("invalidTemplate")));
@property (class, readonly) SkyprintTemplateErrorCode *unknownFormatter __attribute__((swift_name("unknownFormatter")));
@property (class, readonly) SkyprintTemplateErrorCode *unknownVariable __attribute__((swift_name("unknownVariable")));
@property (class, readonly) SkyprintTemplateErrorCode *unknownElementType __attribute__((swift_name("unknownElementType")));
+ (SkyprintKotlinArray<SkyprintTemplateErrorCode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SkyprintTemplateErrorCode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateException")))
@interface SkyprintTemplateException : SkyprintKotlinException
- (instancetype)initWithCode:(SkyprintTemplateErrorCode *)code message:(NSString *)message __attribute__((swift_name("init(code:message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) SkyprintTemplateErrorCode *code __attribute__((swift_name("code")));
@end


/** Một vấn đề tìm thấy lúc [TemplateEngine.validate] hoặc cảnh báo lúc [TemplateEngine.render]. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateIssue")))
@interface SkyprintTemplateIssue : SkyprintBase
- (instancetype)initWithWhere:(NSString *)where message:(NSString *)message __attribute__((swift_name("init(where:message:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateIssue *)doCopyWhere:(NSString *)where message:(NSString *)message __attribute__((swift_name("doCopy(where:message:)")));

/** Một vấn đề tìm thấy lúc [TemplateEngine.validate] hoặc cảnh báo lúc [TemplateEngine.render]. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Một vấn đề tìm thấy lúc [TemplateEngine.validate] hoặc cảnh báo lúc [TemplateEngine.render]. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Một vấn đề tìm thấy lúc [TemplateEngine.validate] hoặc cảnh báo lúc [TemplateEngine.render]. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *where __attribute__((swift_name("where")));
@end


/**
 * Cây mẫu in đã parse từ JSON (DESIGN-009) -- một "bag of nullable fields"
 * thay vì phân cấp lớp riêng từng loại phần tử: JSON mẫu vốn dị hình theo
 * `type`, và field nào cũng có thể mang placeholder cần nội suy trước khi
 * biết nó hợp lệ hay không, nên tách lớp sẽ chỉ dời việc kiểm tra `type`
 * từ đây sang chỗ khác chứ không giảm được gì.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateNode")))
@interface SkyprintTemplateNode : SkyprintBase
- (instancetype)initWithType:(NSString *)type enabled:(BOOL)enabled each:(NSString * _Nullable)each asVar:(NSString * _Nullable)asVar ifExpr:(NSString * _Nullable)ifExpr value:(NSString * _Nullable)value style:(SkyprintTemplateStyle * _Nullable)style columns:(NSArray<SkyprintTemplateColumn *> * _Nullable)columns header:(BOOL)header char:(NSString *)char_ lines:(int32_t)lines partial:(BOOL)partial moduleSize:(int32_t)moduleSize errorCorrection:(NSString *)errorCorrection caption:(NSString * _Nullable)caption barcodeType:(NSString *)barcodeType heightDots:(int32_t)heightDots hri:(BOOL)hri pin:(int32_t)pin pulseMs:(int32_t)pulseMs times:(int32_t)times durationMs:(int32_t)durationMs elements:(NSArray<SkyprintTemplateNode *> * _Nullable)elements align:(NSString *)align __attribute__((swift_name("init(type:enabled:each:asVar:ifExpr:value:style:columns:header:char:lines:partial:moduleSize:errorCorrection:caption:barcodeType:heightDots:hri:pin:pulseMs:times:durationMs:elements:align:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateNode *)doCopyType:(NSString *)type enabled:(BOOL)enabled each:(NSString * _Nullable)each asVar:(NSString * _Nullable)asVar ifExpr:(NSString * _Nullable)ifExpr value:(NSString * _Nullable)value style:(SkyprintTemplateStyle * _Nullable)style columns:(NSArray<SkyprintTemplateColumn *> * _Nullable)columns header:(BOOL)header char:(NSString *)char_ lines:(int32_t)lines partial:(BOOL)partial moduleSize:(int32_t)moduleSize errorCorrection:(NSString *)errorCorrection caption:(NSString * _Nullable)caption barcodeType:(NSString *)barcodeType heightDots:(int32_t)heightDots hri:(BOOL)hri pin:(int32_t)pin pulseMs:(int32_t)pulseMs times:(int32_t)times durationMs:(int32_t)durationMs elements:(NSArray<SkyprintTemplateNode *> * _Nullable)elements align:(NSString *)align __attribute__((swift_name("doCopy(type:enabled:each:asVar:ifExpr:value:style:columns:header:char:lines:partial:moduleSize:errorCorrection:caption:barcodeType:heightDots:hri:pin:pulseMs:times:durationMs:elements:align:)")));

/**
 * Cây mẫu in đã parse từ JSON (DESIGN-009) -- một "bag of nullable fields"
 * thay vì phân cấp lớp riêng từng loại phần tử: JSON mẫu vốn dị hình theo
 * `type`, và field nào cũng có thể mang placeholder cần nội suy trước khi
 * biết nó hợp lệ hay không, nên tách lớp sẽ chỉ dời việc kiểm tra `type`
 * từ đây sang chỗ khác chứ không giảm được gì.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Cây mẫu in đã parse từ JSON (DESIGN-009) -- một "bag of nullable fields"
 * thay vì phân cấp lớp riêng từng loại phần tử: JSON mẫu vốn dị hình theo
 * `type`, và field nào cũng có thể mang placeholder cần nội suy trước khi
 * biết nó hợp lệ hay không, nên tách lớp sẽ chỉ dời việc kiểm tra `type`
 * từ đây sang chỗ khác chứ không giảm được gì.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Cây mẫu in đã parse từ JSON (DESIGN-009) -- một "bag of nullable fields"
 * thay vì phân cấp lớp riêng từng loại phần tử: JSON mẫu vốn dị hình theo
 * `type`, và field nào cũng có thể mang placeholder cần nội suy trước khi
 * biết nó hợp lệ hay không, nên tách lớp sẽ chỉ dời việc kiểm tra `type`
 * từ đây sang chỗ khác chứ không giảm được gì.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *align __attribute__((swift_name("align")));
@property (readonly) NSString * _Nullable asVar __attribute__((swift_name("asVar")));
@property (readonly) NSString *barcodeType __attribute__((swift_name("barcodeType")));
@property (readonly) NSString * _Nullable caption __attribute__((swift_name("caption")));
@property (readonly, getter=char) NSString *char_ __attribute__((swift_name("char_")));
@property (readonly) NSArray<SkyprintTemplateColumn *> * _Nullable columns __attribute__((swift_name("columns")));
@property (readonly) int32_t durationMs __attribute__((swift_name("durationMs")));
@property (readonly) NSString * _Nullable each __attribute__((swift_name("each")));
@property (readonly) NSArray<SkyprintTemplateNode *> * _Nullable elements __attribute__((swift_name("elements")));
@property (readonly) BOOL enabled __attribute__((swift_name("enabled")));
@property (readonly) NSString *errorCorrection __attribute__((swift_name("errorCorrection")));
@property (readonly) BOOL header __attribute__((swift_name("header")));
@property (readonly) int32_t heightDots __attribute__((swift_name("heightDots")));
@property (readonly) BOOL hri __attribute__((swift_name("hri")));
@property (readonly) NSString * _Nullable ifExpr __attribute__((swift_name("ifExpr")));
@property (readonly) int32_t lines __attribute__((swift_name("lines")));
@property (readonly) int32_t moduleSize __attribute__((swift_name("moduleSize")));
@property (readonly) BOOL partial __attribute__((swift_name("partial")));
@property (readonly) int32_t pin __attribute__((swift_name("pin")));
@property (readonly) int32_t pulseMs __attribute__((swift_name("pulseMs")));
@property (readonly) SkyprintTemplateStyle * _Nullable style __attribute__((swift_name("style")));
@property (readonly) int32_t times __attribute__((swift_name("times")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@property (readonly) NSString * _Nullable value __attribute__((swift_name("value")));
@end


/** Đọc JSON mẫu in thành [Template] (REQ-009, DESIGN-009). Lỗi cú pháp/JSON hỏng -> [TemplateException] (INVALID_TEMPLATE), không throw lỗi JSON thô của thư viện parse. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateParser")))
@interface SkyprintTemplateParser : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));

/** Đọc JSON mẫu in thành [Template] (REQ-009, DESIGN-009). Lỗi cú pháp/JSON hỏng -> [TemplateException] (INVALID_TEMPLATE), không throw lỗi JSON thô của thư viện parse. */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)templateParser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintTemplateParser *shared __attribute__((swift_name("shared")));
- (SkyprintTemplate *)parseJson:(NSString *)json __attribute__((swift_name("parse(json:)")));
@end


/** Khai báo dữ liệu hợp lệ cho một loại chứng từ (RECEIPT, PRECHECK, KITCHEN...) -- DESIGN-009. */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateSchema")))
@interface SkyprintTemplateSchema : SkyprintBase
- (instancetype)initWithDocumentType:(NSString *)documentType paths:(NSSet<NSString *> *)paths sample:(id<SkyprintTemplateValue>)sample __attribute__((swift_name("init(documentType:paths:sample:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateSchema *)doCopyDocumentType:(NSString *)documentType paths:(NSSet<NSString *> *)paths sample:(id<SkyprintTemplateValue>)sample __attribute__((swift_name("doCopy(documentType:paths:sample:)")));

/** Khai báo dữ liệu hợp lệ cho một loại chứng từ (RECEIPT, PRECHECK, KITCHEN...) -- DESIGN-009. */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Khai báo dữ liệu hợp lệ cho một loại chứng từ (RECEIPT, PRECHECK, KITCHEN...) -- DESIGN-009. */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Khai báo dữ liệu hợp lệ cho một loại chứng từ (RECEIPT, PRECHECK, KITCHEN...) -- DESIGN-009. */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *documentType __attribute__((swift_name("documentType")));
@property (readonly) NSSet<NSString *> *paths __attribute__((swift_name("paths")));
@property (readonly) id<SkyprintTemplateValue> sample __attribute__((swift_name("sample")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateStyle")))
@interface SkyprintTemplateStyle : SkyprintBase
- (instancetype)initWithAlign:(NSString *)align bold:(BOOL)bold width:(int32_t)width height:(int32_t)height inverse:(BOOL)inverse underline:(BOOL)underline __attribute__((swift_name("init(align:bold:width:height:inverse:underline:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateStyle *)doCopyAlign:(NSString *)align bold:(BOOL)bold width:(int32_t)width height:(int32_t)height inverse:(BOOL)inverse underline:(BOOL)underline __attribute__((swift_name("doCopy(align:bold:width:height:inverse:underline:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *align __attribute__((swift_name("align")));
@property (readonly) BOOL bold __attribute__((swift_name("bold")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) BOOL inverse __attribute__((swift_name("inverse")));
@property (readonly) BOOL underline __attribute__((swift_name("underline")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/**
 * Dữ liệu chứng từ đưa vào [TemplateEngine.render] (REQ-009, DESIGN-009).
 * Cây giá trị tối giản kiểu JSON -- không phải Map/List trần để [PathResolver]
 * và [ConditionEvaluator] xử lý thống nhất một loại, không phải downcast
 * `Any?` rải rác khắp engine.
 */
__attribute__((swift_name("TemplateValue")))
@protocol SkyprintTemplateValue
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueArr")))
@interface SkyprintTemplateValueArr : SkyprintBase <SkyprintTemplateValue>
- (instancetype)initWithItems:(NSArray<id<SkyprintTemplateValue>> *)items __attribute__((swift_name("init(items:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateValueArr *)doCopyItems:(NSArray<id<SkyprintTemplateValue>> *)items __attribute__((swift_name("doCopy(items:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<id<SkyprintTemplateValue>> *items __attribute__((swift_name("items")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueBool")))
@interface SkyprintTemplateValueBool : SkyprintBase <SkyprintTemplateValue>
- (instancetype)initWithValue:(BOOL)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateValueBool *)doCopyValue:(BOOL)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueCompanion")))
@interface SkyprintTemplateValueCompanion : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintTemplateValueCompanion *shared __attribute__((swift_name("shared")));
- (id<SkyprintTemplateValue>)fromJsonJson:(NSString *)json __attribute__((swift_name("fromJson(json:)")));
- (id<SkyprintTemplateValue>)ofValue:(id _Nullable)value __attribute__((swift_name("of(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueNull")))
@interface SkyprintTemplateValueNull : SkyprintBase <SkyprintTemplateValue>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)null __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintTemplateValueNull *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueNum")))
@interface SkyprintTemplateValueNum : SkyprintBase <SkyprintTemplateValue>
- (instancetype)initWithValue:(double)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateValueNum *)doCopyValue:(double)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) double value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueObj")))
@interface SkyprintTemplateValueObj : SkyprintBase <SkyprintTemplateValue>
- (instancetype)initWithFields:(NSDictionary<NSString *, id<SkyprintTemplateValue>> *)fields __attribute__((swift_name("init(fields:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateValueObj *)doCopyFields:(NSDictionary<NSString *, id<SkyprintTemplateValue>> *)fields __attribute__((swift_name("doCopy(fields:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, id<SkyprintTemplateValue>> *fields __attribute__((swift_name("fields")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueStr")))
@interface SkyprintTemplateValueStr : SkyprintBase <SkyprintTemplateValue>
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (SkyprintTemplateValueStr *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemplateValueKt")))
@interface SkyprintTemplateValueKt : SkyprintBase

/** Chuỗi hiển thị mặc định khi nội suy vào text (chưa qua formatter nào). */
+ (NSString *)displayString:(id<SkyprintTemplateValue>)receiver __attribute__((swift_name("displayString(_:)")));

/** Truthy theo quy ước [ConditionEvaluator] (DESIGN-009): không null, không rỗng, khác 0, khác false. */
+ (BOOL)isTruthy:(id<SkyprintTemplateValue>)receiver __attribute__((swift_name("isTruthy(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinPair")))
@interface SkyprintKotlinPair<__covariant A, __covariant B> : SkyprintBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("init(first:second:)"))) __attribute__((objc_designated_initializer));
- (SkyprintKotlinPair<A, B> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("doCopy(first:second:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface SkyprintKotlinRuntimeException : SkyprintKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface SkyprintKotlinIllegalStateException : SkyprintKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface SkyprintKotlinCancellationException : SkyprintKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SkyprintKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * An asynchronous data stream that sequentially emits values and completes normally or with an exception.
 *
 * _Intermediate operators_ on the flow such as [map], [filter], [take], [zip], etc are functions that are
 * applied to the _upstream_ flow or flows and return a _downstream_ flow where further operators can be applied to.
 * Intermediate operations do not execute any code in the flow and are not suspending functions themselves.
 * They only set up a chain of operations for future execution and quickly return.
 * This is known as a _cold flow_ property.
 *
 * _Terminal operators_ on the flow are either suspending functions such as [collect], [single], [reduce], [toList], etc.
 * or [launchIn] operator that starts collection of the flow in the given scope.
 * They are applied to the upstream flow and trigger execution of all operations.
 * Execution of the flow is also called _collecting the flow_  and is always performed in a suspending manner
 * without actual blocking. Terminal operators complete normally or exceptionally depending on successful or failed
 * execution of all the flow operations in the upstream. The most basic terminal operator is [collect], for example:
 *
 * ```
 * try {
 *     flow.collect { value ->
 *         println("Received $value")
 *     }
 * } catch (e: Exception) {
 *     println("The flow has thrown an exception: $e")
 * }
 * ```
 *
 * By default, flows are _sequential_ and all flow operations are executed sequentially in the same coroutine,
 * with an exception for a few operations specifically designed to introduce concurrency into flow
 * execution such as [buffer] and [flatMapMerge]. See their documentation for details.
 *
 * The `Flow` interface does not carry information whether a flow is a _cold_ stream that can be collected repeatedly and
 * triggers execution of the same code every time it is collected, or if it is a _hot_ stream that emits different
 * values from the same running source on each collection. Usually flows represent _cold_ streams, but
 * there is a [SharedFlow] subtype that represents _hot_ streams. In addition to that, any flow can be turned
 * into a _hot_ one by the [stateIn] and [shareIn] operators, or by converting the flow into a hot channel
 * via the [produceIn] operator.
 *
 * ### Flow builders
 *
 * There are the following basic ways to create a flow:
 *
 * - [flowOf(...)][flowOf] functions to create a flow from a fixed set of values.
 * - [asFlow()][asFlow] extension functions on various types to convert them into flows.
 * - [flow { ... }][flow] builder function to construct arbitrary flows from
 *   sequential calls to [emit][FlowCollector.emit] function.
 * - [channelFlow { ... }][channelFlow] builder function to construct arbitrary flows from
 *   potentially concurrent calls to the [send][kotlinx.coroutines.channels.SendChannel.send] function.
 * - [MutableStateFlow] and [MutableSharedFlow] define the corresponding constructor functions to create
 *   a _hot_ flow that can be directly updated.
 *
 * ### Flow constraints
 *
 * All implementations of the `Flow` interface must adhere to two key properties described in detail below:
 *
 * - Context preservation.
 * - Exception transparency.
 *
 * These properties ensure the ability to perform local reasoning about the code with flows and modularize the code
 * in such a way that upstream flow emitters can be developed separately from downstream flow collectors.
 * A user of a flow does not need to be aware of implementation details of the upstream flows it uses.
 *
 * ### Context preservation
 *
 * The flow has a context preservation property: it encapsulates its own execution context and never propagates or leaks
 * it downstream, thus making reasoning about the execution context of particular transformations or terminal
 * operations trivial.
 *
 * There is only one way to change the context of a flow: the [flowOn][Flow.flowOn] operator
 * that changes the upstream context ("everything above the `flowOn` operator").
 * For additional information refer to its documentation.
 *
 * This reasoning can be demonstrated in practice:
 *
 * ```
 * val flowA = flowOf(1, 2, 3)
 *     .map { it + 1 } // Will be executed in ctxA
 *     .flowOn(ctxA) // Changes the upstream context: flowOf and map
 *
 * // Now we have a context-preserving flow: it is executed somewhere but this information is encapsulated in the flow itself
 *
 * val filtered = flowA // ctxA is encapsulated in flowA
 *    .filter { it == 3 } // Pure operator without a context yet
 *
 * withContext(Dispatchers.Main) {
 *     // All non-encapsulated operators will be executed in Main: filter and single
 *     val result = filtered.single()
 *     myUi.text = result
 * }
 * ```
 *
 * From the implementation point of view, it means that all flow implementations should
 * only emit from the same coroutine context.
 * This constraint is efficiently enforced by the default [flow] builder.
 * The [flow] builder should be used if the flow implementation does not start any coroutines.
 * Its implementation prevents most of the development mistakes:
 *
 * ```
 * val myFlow = flow {
 *     // GlobalScope.launch { // is prohibited
 *     // launch(Dispatchers.IO) { // is prohibited
 *     // withContext(CoroutineName("myFlow")) { // is prohibited
 *     emit(1) // OK
 *     coroutineScope {
 *         emit(2) // OK -- still the same coroutine
 *     }
 * }
 * ```
 *
 * Use [channelFlow] if the collection and emission of a flow are to be separated into multiple coroutines.
 * It encapsulates all the context preservation work and allows you to focus on your
 * domain-specific problem, rather than invariant implementation details.
 * It is possible to use any combination of coroutine builders from within [channelFlow].
 *
 * If you are looking for performance and are sure that no concurrent emits and context jumps will happen,
 * the [flow] builder can be used alongside a [coroutineScope] or [supervisorScope] instead:
 * - Scoped primitive should be used to provide a [CoroutineScope].
 * - Changing the context of emission is prohibited, no matter whether it is `withContext(ctx)` or
 *   a builder argument (e.g. `launch(ctx)`).
 * - Collecting another flow from a separate context is allowed, but it has the same effect as
 *   applying the [flowOn] operator to that flow, which is more efficient.
 *
 * ### Exception transparency
 *
 * When `emit` or `emitAll` throws, the Flow implementations must immediately stop emitting new values and finish with an exception.
 * For diagnostics or application-specific purposes, the exception may be different from the one thrown by the emit operation,
 * suppressing the original exception as discussed below.
 * If there is a need to emit values after the downstream failed, please use the [catch][Flow.catch] operator.
 *
 * The [catch][Flow.catch] operator only catches upstream exceptions, but passes
 * all downstream exceptions. Similarly, terminal operators like [collect][Flow.collect]
 * throw any unhandled exceptions that occur in their code or in upstream flows, for example:
 *
 * ```
 * flow { emitData() }
 *     .map { computeOne(it) }
 *     .catch { ... } // catches exceptions in emitData and computeOne
 *     .map { computeTwo(it) }
 *     .collect { process(it) } // throws exceptions from process and computeTwo
 * ```
 * The same reasoning can be applied to the [onCompletion] operator that is a declarative replacement for the `finally` block.
 *
 * All exception-handling Flow operators follow the principle of exception suppression:
 *
 * If the upstream flow throws an exception during its completion when the downstream exception has been thrown,
 * the downstream exception becomes superseded and suppressed by the upstream exception, being a semantic
 * equivalent of throwing from `finally` block. However, this doesn't affect the operation of the exception-handling operators,
 * which consider the downstream exception to be the root cause and behave as if the upstream didn't throw anything.
 *
 * Failure to adhere to the exception transparency requirement can lead to strange behaviors which make
 * it hard to reason about the code because an exception in the `collect { ... }` could be somehow "caught"
 * by an upstream flow, limiting the ability of local reasoning about the code.
 *
 * Flow machinery enforces exception transparency at runtime and throws [IllegalStateException] on any attempt to emit a value,
 * if an exception has been thrown on previous attempt.
 *
 * ### Reactive streams
 *
 * Flow is [Reactive Streams](http://www.reactive-streams.org/) compliant, you can safely interop it with
 * reactive streams using `Flow.asPublisher` and `Publisher.asFlow` from `kotlinx-coroutines-reactive` module.
 *
 * ### Not stable for inheritance
 *
 * **The `Flow` interface is not stable for inheritance in 3rd party libraries**, as new methods
 * might be added to this interface in the future, but is stable for use.
 *
 * Use the `flow { ... }` builder function to create an implementation, or extend [AbstractFlow].
 * These implementations ensure that the context preservation property is not violated, and prevent most
 * of the developer mistakes related to concurrency, inconsistent flow dispatchers, and cancellation.
 */
__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol SkyprintKotlinx_coroutines_coreFlow
@required

/**
 * Accepts the given [collector] and [emits][FlowCollector.emit] values into it.
 *
 * This method can be used along with SAM-conversion of [FlowCollector]:
 * ```
 * myFlow.collect { value -> println("Collected $value") }
 * ```
 *
 * ### Method inheritance
 *
 * To ensure the context preservation property, it is not recommended implementing this method directly.
 * Instead, [AbstractFlow] can be used as the base type to properly ensure flow's properties.
 *
 * All default flow implementations ensure context preservation and exception transparency properties on a best-effort basis
 * and throw [IllegalStateException] if a violation was detected.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<SkyprintKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol SkyprintKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction3")))
@protocol SkyprintKotlinSuspendFunction3 <SkyprintKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 p3:(id _Nullable)p3 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:p3:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface SkyprintKotlinByteArray : SkyprintBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(SkyprintByte *(^)(SkyprintInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SkyprintKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface SkyprintKotlinEnumCompanion : SkyprintBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SkyprintKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SkyprintKotlinArray<T> : SkyprintBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SkyprintInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SkyprintKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end


/**
 * [FlowCollector] is used as an intermediate or a terminal collector of the flow and represents
 * an entity that accepts values emitted by the [Flow].
 *
 * This interface should usually not be implemented directly, but rather used as a receiver in a [flow] builder when implementing a custom operator,
 * or with SAM-conversion.
 * Implementations of this interface are not thread-safe.
 *
 * Example of usage:
 *
 * ```
 * val flow = getMyEvents()
 * try {
 *     flow.collect { value ->
 *         println("Received $value")
 *     }
 *     println("My events are consumed successfully")
 * } catch (e: Throwable) {
 *     println("Exception from the flow: $e")
 * }
 * ```
 */
__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol SkyprintKotlinx_coroutines_coreFlowCollector
@required

/**
 * Collects the value emitted by the upstream.
 * This method is not thread-safe and should not be invoked concurrently.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol SkyprintKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface SkyprintKotlinByteIterator : SkyprintBase <SkyprintKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SkyprintByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
